#pragma once

#include<vector>
#include<map>
#include"except.h"

namespace frame{

template<class TypeKey, class TypeVal>
class XVector
{
public:
	XVector() = default;
	XVector(const std::string& name) :_name(name) {}
	bool isExist(const TypeKey& key) const { if (_index.count(key) == 0) return false; return true; }
	const TypeVal& at(size_t ind) const { return _value.at(ind); }
	TypeVal& at(size_t ind) { return const_cast<TypeVal&>(std::as_const(*this).at(ind)); }
	const TypeVal& operator[](size_t ind)const { return at(ind); }
	TypeVal& operator[](size_t ind) { return at(ind); }
	const TypeVal& find(TypeKey key) const {
		if (_index.count(key) == 0)
			if (!_name.empty() && typeid(key) == typeid(std::string)) throw exception::find_no_element("xvector", "", _name);
			else throw exception::find_no_element("xvector");
		return _value.at(_index.find(key)->second);
	}
	TypeVal& find(TypeKey key) { return const_cast<TypeVal&>(std::as_const(*this).find(key)); }
	TypeKey key(size_t ind) const { return _key.at(ind); }
	size_t index(const TypeKey& key) const {
		for (size_t i = 0; i < _key.size(); i++) if (_key.at(i) == key) return i;
		throw exception::find_no_element("xvector");
	}
	void add(TypeKey key, const TypeVal& val) {
		_index.insert(std::pair<TypeKey, size_t>(key, size()));
		_key.push_back(key); _value.push_back(val);
	}
	bool operator==(const XVector& a) const {
		if (size() != a.size() || _name != a._name) return false;
		for (size_t i = 0; i < size(); i++) if (key(i) != a.key(i) || at(i) != a.at(i)) return false;
		return true;
	}
	size_t size() const { return _key.size(); }
	void clear() { _index.clear(); _key.clear(); _value.clear(); _name.clear(); }

private:
	std::string _name;
	std::map<TypeKey, size_t> _index;
	std::vector<TypeKey> _key;
	std::vector<TypeVal> _value;
};

}