
#include"rand.h"
#include"except.h"
#include<numeric>

long long frame::randll(long long minVal, long long maxVal) {
    return minVal + (maxVal - minVal) * randd(0, 1);
}

int frame::randi(int minVal, int maxVal) {
    return minVal + (maxVal - minVal) * randd(0, 1);
}

double frame::randd(double minVal, double maxVal) {
    return minVal + (maxVal - minVal) * rand() / RAND_MAX;
}

std::vector<double> frame::randd(const std::vector<double>& minVal, const std::vector<double>& maxVal) {
    if (minVal.size() != maxVal.size()) throw exception::size_not_match(minVal.size(), maxVal.size());
    std::vector<double> res; res.reserve(minVal.size());
    for (size_t i = 0; i < minVal.size(); i++) {
        if (minVal[i] > maxVal[i]) throw exception::bad_range(std::to_string(minVal[i]), std::to_string(maxVal[i]));
        res.push_back(randd(minVal[i], maxVal[i]));
    }
    return res;
}

std::vector<double> frame::getWheel(const std::vector<double>& value, WheelType type) {
    std::vector<double> wheel(value.size());
    double sum = std::accumulate(value.begin(), value.end(), 0); 
    if (type == WheelType::Itself) {
        if (wheel.size() == 1) wheel[0] = 1;
        else {
            wheel[0] = value[0] / sum;
            for (size_t i = 1; i < wheel.size(); i++) wheel[i] = wheel[i - 1] + value[i] / sum;
        }
    }
    else throw exception::bad_param();
    return wheel;
}

size_t frame::playWheel(const std::vector<double>& wheel) {
    double r = randd(0, 1);
    for (size_t i = 0; i < wheel.size(); i++) if (r <= wheel.at(i)) return i;
    throw exception::unknown();
}

