#pragma once

#include"except.h"
#include<vector>
#include<numeric>
#include<optional>
#include"rand.h"
#include"toolkit.h"

namespace frame{

template<typename Type>
class HighDimVariable
{
public:
	HighDimVariable() = default;
	HighDimVariable( std::optional<std::string> name, const std::vector<size_t>& sizeOfEachDim, const Type& initVal) {
		if (name) _name = *name;
		assign(sizeOfEachDim, initVal);
	}
	HighDimVariable(std::optional<std::string> name, const std::vector<size_t>& sizeOfEachDim, const std::vector<Type>& data) {
		size_t total = std::accumulate(sizeOfEachDim.begin(), sizeOfEachDim.end(), 1, std::multiplies<double>());
		if (data.size() != total) throw exception::size_not_match(data.size(), total);
		assign(sizeOfEachDim, data.at(0));
		_data = data;
		_maxIndex = sizeOfEachDim;
	}
	size_t size() const { return _data.size(); }
	void assign(const std::vector<size_t>& sizeOfEachDim, const Type& initVal) {
		_maxIndex = sizeOfEachDim; _productSize.assign(sizeOfEachDim.size(), 1);
		for (int i = sizeOfEachDim.size() - 2; i >= 0; i--) {
			_productSize.at(i) = _productSize.at(i + 1) * _maxIndex.at(i + 1); }
		size_t _size = _productSize.front() * _maxIndex.front();
		_data.assign(_size, initVal);
	}
	void setRand(const Type& minVal, const Type& maxVal) {
		if (typeid(Type) == typeid(int)) {
			for (size_t i = 0; i < _data.size(); i++) _data.at(i) = randi(minVal, maxVal);
		}
		else if (typeid(Type) == typeid(double)) {
			for (size_t i = 0; i < _data.size(); i++) _data.at(i) = randd(minVal, maxVal);
		}
		else throw exception::type_not_match(typeid(Type).name(), "not a number");
	}
	void forceInBoundary(const Type& minVal, const Type& maxVal) {
		if (!isNumber(typeid(Type))) throw exception::type_not_match(typeid(Type).name(), "not a number");
		for (size_t i = 0; i < _data.size(); i++) {
			if (_data.at(i) < minVal) _data.at(i) = minVal;
			if (_data.at(i) > maxVal) _data.at(i) = maxVal;
		}
	}
	Type& operator()(const std::vector<size_t>& index) { return const_cast<Type&>(std::as_const(*this)(index)); }
	const Type& operator()(const std::vector<size_t>& index) const {
		if (index.size() != _maxIndex.size()) throw exception::size_not_match(index.size(), _maxIndex.size());
		for (size_t i = 0; i < index.size(); i++) if (index.at(i) >= _maxIndex.at(i)) throw exception::out_of_range(index.at(i),0, _maxIndex.at(i));
		size_t dataIndex = 0;
		for (size_t i = 0; i < index.size(); i++) dataIndex += index.at(i) * _productSize.at(i);
		return _data.at(dataIndex);
	}
	size_t getMaxIndex(size_t iDim) const {
		return _maxIndex.at(iDim);
	}
	size_t nDim() const {
		return _maxIndex.size();
	}
	const std::vector<Type>& getData() const {
		return _data;
	}
	std::vector<Type>& getData() {
		return _data;
	}

private:
	std::string _name;
	std::vector<size_t> _maxIndex;
	std::vector<Type> _data;
	std::vector<size_t> _productSize;
};

}