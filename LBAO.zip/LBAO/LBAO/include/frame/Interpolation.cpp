
#include"math.h"
#include"except.h"
#include"toolkit.h"
#include<cmath>
#include <boost/math/tools/roots.hpp>
#include<utility>
#include"rand.h"

namespace mf = frame;

std::vector<double> frame::Interpolation::predict(const std::vector<double>& x) const {
	std::vector<double> res; res.reserve(x.size());
	for (size_t i = 0; i < x.size(); i++) res.push_back(predict(x.at(i)));
	return res;
}

frame::LinearInterpolation::LinearInterpolation(const std::vector<double>& x, const std::vector<double>& y)
	: Interpolation(x, y)
{
	// do nothing
}

std::vector<double> frame::LinearInterpolation::predict(const std::vector<double>& x) const {
	return Interpolation::predict(x);
}

frame::Interpolation::Interpolation(const std::vector<double>& x, const std::vector<double>& y) : _x(x), _y(y) {
	if (_x.size() != _y.size()) throw exception::size_not_match(_x.size(), _y.size());
	if (mf::hasRepeat(_x)) throw exception::has_reduplicative_element(mf::combine_to_string(x, " "));
	auto index = mf::sort(x, true);
	mf::rearrange(index, _x); mf::rearrange(index, _y);
}

double frame::LinearInterpolation::predict(double x) const {
	if (x < _x.front() || x > _x.back()) throw exception::out_of_range(x, _x.front(), _x.back());
	for (size_t i = 0; i < _x.size() - 1; i++) {
		double x0 = _x.at(i); double x1 = _x.at(i + 1);
		double y0 = _y.at(i); double y1 = _y.at(i + 1);
		if (x0 <= x && x < x1) return y0 * (x1 - x) / (x1 - x0) + y1 * (x - x0) / (x1 - x0);
	}
	if (x == _x.back()) return _y.back();
	throw exception::unknown();
}

frame::LagrangeInterpolation::LagrangeInterpolation(const std::vector<double>& x, const std::vector<double>& y)
	: Interpolation(x, y)
{
	// do nothing
}

double frame::LagrangeInterpolation::predict(double x) const {
	double y = 0; size_t n = _x.size();
	std::vector<double> L; L.reserve(n); //lagrange������ֵ����ʽ

	for (size_t k = 0; k < n; k++) {
		double fenmu = 1; double fenzi = 1;
		for (size_t m = 0; m < n; m++) {
			if (m == k) continue;
			fenzi *= (x - _x.at(m));
			fenmu *= (_x.at(k) - _x.at(m));
		}
		L.push_back(fenzi / fenmu);
	}
	for (size_t k = 0; k < n; k++) y += _y.at(k) * L.at(k);
	return y;
}

std::vector<double> frame::LagrangeInterpolation::predict(const std::vector<double>& x) const {
	return Interpolation::predict(x);
}

double frame::InterpolationPoint::legendre(unsigned int n, double x){
	return std::legendre(n, x);
}

double frame::InterpolationPoint::legendre_first_derivative(unsigned int n, double x){
	if (x == 1) throw exception::unknown();
	return n*(legendre(n-1,x) -  x* legendre(n,x))/(1-x*x);
}

std::vector<double> frame::InterpolationPoint::get_legendre_gauss_points(unsigned int n){
	using Vec = std::vector<double>;
	if (n == 1) return Vec{ 0 };
	else if (n == 2) return Vec{ 0.57735, -0.57735 };
	else if (n == 3) return Vec{ -0.774597, 0, 0.774597 };
	else if (n == 4) return Vec{ 0.861136, 0.339981, -0.339981, -0.861136 };
	else if (n == 5) return Vec{ -0.90618, 0.538469, -0.538469, 0.90618, 0 };
	else if (n == 6) return Vec{ -0.661209, -0.93247, -0.238619, 0.238619, 0.661209, 0.93247 };
	else if (n == 7) return Vec{ 0.741531, 0 ,-0.741531 ,-0.405845, 0.405845, 0.949108 ,-0.949108 };
	else if (n == 8) return Vec{ -0.183435, -0.796666, -0.525532, -0.96029, 0.796666 ,0.183435, 0.96029, 0.525532 };
	else if (n == 9) return Vec{ 0, -0.613371, 0.836031, -0.836031, 0.613371 ,-0.324253, 0.324253, 0.96816 ,-0.96816 };
	else if (n == 10) return Vec{ 0.148874, -0.148874, -0.865063, 0.865063, 0.67941,-0.67941, -0.433395,0.433395 , 0.973907,  -0.973907 };
	else if (n == 11) return Vec{ 0.978229,-0.978229, -0.887063 ,0, 0.887063, 0.730152 ,-0.730152,0.269543, -0.269543 ,-0.519096 , 0.519096 };
	else if (n == 12) return Vec{ -0.904117, 0.904117, 0.587318, -0.587318, -0.769903, 0.769903,0.125233,-0.125233, -0.981561,  0.981561,  0.367831, -0.367831 };
	else if (n == 13) return Vec{ -0.642349, 0.642349,0, 0.917598,-0.917598, 0.448493, -0.448493,0.801578,-0.801578, 0.984183,   -0.984183, 0.230458,   -0.230458 };
	else if (n == 14) return Vec{ -0.827201,0.827201, 0.319112, -0.319112, 0.687293,-0.687293,  0.515249, -0.515249 - 0.986284,0.986284, 0.108055,-0.108055 , 0.928435 , -0.928435 };
	else if (n == 15) return Vec{ 0.201194,  -0.201194, -0.394151,0.394151, 0.724418, -0.724418, -0.570972, 0.570972,  0.987993, -0.987993, -0.848207,  0.848207, -0.937273 , 0.937273,0 };
	else throw frame::exception::unknown();

	std::vector<double> rootList; rootList.reserve(n);
	unsigned int total = 0, maxIter = 1000; 
	while (rootList.size() < n && total++ <= maxIter) {
		double guess = randd(-1, 1); double root;
		try
		{
			root = boost::math::tools::newton_raphson_iterate(
				[n](double const& x)-> std::pair<double, double>
				{
					return std::make_pair(
						InterpolationPoint::legendre(n, x),
						InterpolationPoint::legendre_first_derivative(n, x)
					);
				},
				guess, -1.0, 1.0, 50);
		}
		catch (...)
		{
		}
		if (!frame::hasSimilar(root, rootList, std::pow(10, -6))) rootList.push_back(root);
	}
	if (total > maxIter && rootList.size() < n) throw exception::unknown();
	return rootList;
}
/*
std::vector<double> frame::InterpolationPoint::get_legendre_gauss_radau_points(unsigned int n){
	std::vector<double> rootList; rootList.reserve(n);
	unsigned int total = 0, maxIter = 1000;
	while (rootList.size() < n && total++ <= maxIter) {
		double guess = randd(-1, 1); double root;
		try
		{
			root = boost::math::tools::newton_raphson_iterate(
				[n](double const& x)-> std::pair<double, double>
				{
					return std::make_pair(
						InterpolationPoint::legendre(n-1, x) + InterpolationPoint::legendre(n, x),
						InterpolationPoint::legendre_first_derivative(n-1, x) + InterpolationPoint::legendre_first_derivative(n, x)
					);
				},
				guess, -1.0, 1.0, 50);
		}
		catch (...)
		{
		}
		if (!frame::hasSimilar(root, rootList, std::pow(10, -6))) rootList.push_back(root);
	}
	if (total > maxIter && rootList.size() < n) throw exception::unknown();
	return rootList;
}

std::vector<double> frame::InterpolationPoint::get_legendre_gauss_lobatto_points(unsigned int n){
	std::vector<double> rootList; rootList.reserve(n);
	unsigned int total = 0, maxIter = 1000;
	while (rootList.size() < n && total++ <= maxIter) {
		double guess = randd(-1, 1); double root;
		try
		{
			root = boost::math::tools::newton_raphson_iterate(
				[n](double const& x)-> std::pair<double, double>
				{
					return std::make_pair(
						InterpolationPoint::legendre(n - 1, x) + InterpolationPoint::legendre(n, x),
						InterpolationPoint::legendre_first_derivative(n - 1, x) + InterpolationPoint::legendre_first_derivative(n, x)
					);
				},
				guess, -1.0, 1.0, 50);
		}
		catch (...)
		{
		}
		if (!frame::hasSimilar(root, rootList, std::pow(10, -6))) rootList.push_back(root);
	}
	if (total > maxIter && rootList.size() < n) throw exception::unknown();
	return rootList;
}
*/

