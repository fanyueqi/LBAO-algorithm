#pragma once

#include<vector>
#include<string>
#include"xvector.h"
#include<optional>
#include<functional>

namespace frame{

template<typename FunctionType, typename ValueType, typename TraceType>
class Function
{
public:
	Function(
		std::function<void(ValueType&, size_t nDim, double val)> assign_value,
		std::function<void(TraceType&, size_t nTime, double val)> assign_trace,
		std::function<size_t(const FunctionType&)> get_func_n_time,
		std::function<size_t(const FunctionType&)> get_func_n_dim,
		std::function<size_t(const ValueType&)> get_value_n_dim,
		std::function <const ValueType&(const FunctionType&, size_t)> func_get_at_time,
		std::function<const double&(const ValueType&, size_t)> value_get_at_dim,
		std::function<double&(TraceType&, size_t t)> trace_get_at_time,
		std::function<void(ValueType&, const ValueType&)> add_equal,
		std::function<void(ValueType&, const ValueType&)> minus_equal,
		std::function<void(ValueType&, const ValueType& minVal, const ValueType& maxVal)> force_in_bound
	): _assign_value(assign_value), _assign_trace(assign_trace), _get_func_n_time(get_func_n_time), _get_func_n_dim(get_func_n_dim),
	_get_value_n_dim(get_value_n_dim), _func_get_at_time(func_get_at_time), _value_get_at_dim(value_get_at_dim),
		_trace_get_at_time(trace_get_at_time), _add_equal(add_equal), _minus_equal(minus_equal), _force_in_bound(force_in_bound)
	{
		// do nothing
	}

	void add(const std::string& name, const FunctionType& func, std::optional<ValueType> lowerBound, std::optional<ValueType> upperBound) {
		if (_data.size() == 0) {
			if (_get_func_n_time(func) == 0 || _get_func_n_dim(func) == 0) throw exception::empty();
			_nTime = _get_func_n_time(func);
		}
		else {
			if (_data.isExist(name)) throw exception::repeated_element(name, "");
			if (_get_func_n_time(func) != _nTime) throw exception::size_not_match(_get_func_n_time(func), _nTime);
			if (_get_func_n_dim(func) ==0 ) throw exception::empty();
		}

		_nDim.push_back(_get_func_n_dim(func));
		_data.add(name, func);

		ValueType minVal, maxVal;
		if (!lowerBound) _assign_value(*lowerBound, _nDim.back(), std::pow(10, -9));
		if (!upperBound) _assign_value(*upperBound, _nDim.back(), std::pow(10, 9));
		
		_lowerBound.add(name, *lowerBound); _upperBound.add(name, *upperBound);
	}
	XVector<std::string, ValueType> getValueAtTime(size_t t) const {
		XVector<std::string, ValueType> res;
		for (size_t s = 0; s < _data.size(); s++) res.add(_data.key(s), _func_get_at_time(_data.at(s),t));
		return res;
	}
	const ValueType& getValueAtTime(std::string name, size_t tInd) const {
		return _func_get_at_time(_data.find(name),tInd);
	}
	const ValueType& getValueAtTime(size_t sInd, size_t tInd) const {
		return _func_get_at_time(_data.at(sInd),tInd);
	}
	ValueType& getValueAtTime(std::string name, size_t tInd) {
		return const_cast<ValueType&>(std::as_const(*this).getValueAtTime(name, tInd));
	}
	ValueType& getValueAtTime(size_t sInd, size_t tInd) {
		return const_cast<ValueType&>(std::as_const(*this).getValueAtTime(sInd, tInd));
	}
	std::string getName(size_t sInd) const {
		return _data.key(sInd);
	}
	std::vector<std::string> getName() const {
		std::vector<std::string> res; res.reserve(_data.size());
		for (size_t i = 0; i < _data.size(); i++) res.push_back(_data.key(i));
		return res;
	}
	void setValueAtTime(const XVector<std::string, ValueType>& val, size_t t, std::string sign) { // += �� -= �� =
		if (val.size() != _data.size()) throw exception::size_not_match(val.size(), _data.size());
		for (size_t i = 0; i < val.size(); i++) {
			std::string name = val.key(i); auto& state = getValueAtTime(name, t);
			if (_get_value_n_dim(val.at(i)) != _get_value_n_dim(state)) throw exception::size_not_match(_get_value_n_dim(val.at(i)), _get_value_n_dim(state));
			if (sign == "=") state = val.at(i);
			else if (sign == "+=") { _add_equal(state, val.at(i)); }
			else if (sign == "-=") { _minus_equal(state, val.at(i));}
			else throw exception::bad_symbol(sign);
		}
	}
	XVector<std::string, std::vector<TraceType>> getTrajectory() const { 
		XVector<std::string, std::vector<TraceType>> result;
		for (size_t i = 0; i < _data.size(); i++) {
			std::vector<TraceType> trajectoryList; trajectoryList.reserve(_nDim.at(i));
			for (size_t j = 0; j < _nDim.at(i); j++) {
				TraceType trajectory; _assign_trace(trajectory, _nTime, 0);
				for (size_t k = 0; k < _nTime; k++) _trace_get_at_time(trajectory, k) = _value_get_at_dim(getValueAtTime(i,k),j);
				trajectoryList.push_back(trajectory);
			}
			result.add(_data.key(i), trajectoryList);
		}
		return result;
	}
	void forceInBoundary(size_t stateInd, size_t tInd) {
		if (tInd < 0 || tInd >= _nTime) throw exception::out_of_range(tInd, 0, _nTime - 1);
		auto& state = getValueAtTime(stateInd, tInd);
		_force_in_bound(state, _lowerBound.at(stateInd), _upperBound.at(stateInd));
	}
	void forceInBoundary(const std::string& name) {
		size_t ind = _data.index(name);
		for (size_t t = 0; t < nTime(); t++) forceInBoundary(ind, t);
	}

	size_t size()const {
		return _data.size();
	}
	const std::vector<size_t>& nDim() const {
		return _nDim;
	}
	size_t nTime() const {
		return _nTime;
	}

	const XVector<std::string, FunctionType>& data() const {
		return _data;
	}

protected:
	XVector<std::string, FunctionType> _data;
	XVector<std::string, ValueType> _lowerBound;
	XVector<std::string, ValueType> _upperBound;
	size_t _nTime{ 0 };
	std::vector<size_t> _nDim;

	std::function<void(ValueType&, size_t dim, double val)> _assign_value;
	std::function<void(TraceType&, size_t t, double val)> _assign_trace;
	std::function<size_t(const FunctionType&)> _get_func_n_time;
	std::function<size_t(const FunctionType&)> _get_func_n_dim;
	std::function<size_t(const ValueType&)> _get_value_n_dim;
	std::function <const ValueType&(const FunctionType&, size_t)> _func_get_at_time;
	std::function<const double&(const ValueType&, size_t)> _value_get_at_dim;
	std::function<double&(TraceType&, size_t t)> _trace_get_at_time;
	std::function<void(ValueType&, const ValueType&)> _add_equal;
	std::function<void(ValueType&, const ValueType&)> _minus_equal;
	std::function<void(ValueType&, const ValueType& minVal, const ValueType& maxVal)> _force_in_bound;
};

}