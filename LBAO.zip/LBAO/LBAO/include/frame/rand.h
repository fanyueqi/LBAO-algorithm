#pragma once

#include<vector>

namespace frame {

long long randll(long long minVal, long long maxVal);
int randi(int minVal, int maxVal);
double randd(double minVal, double maxVal);
std::vector<double> randd(const std::vector<double>& minVal, const std::vector<double>& maxVal);
enum class WheelType { Itself };
std::vector<double> getWheel(const std::vector<double>& value, WheelType type);
size_t playWheel(const std::vector<double>& wheel);

}