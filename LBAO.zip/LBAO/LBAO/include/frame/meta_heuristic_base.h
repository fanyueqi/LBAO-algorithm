#pragma once

#include"../frame/except.h"
#include<vector>
#include<functional>
#include"../frame/threadpool.h"

namespace frame {

template<typename Individual>
class MetaHeuristicBase
{
public:
	enum class RepeatType { Init, None }; //�����ظ�����ķ�ʽ
	enum class ConvergeType { Best, Avg, None };

	static inline const int REPORT_INIT = 0;
	static inline const int REPORT_FITNESS = 1;
	static inline const int REPORT_ADJUST = 2;
	static inline const int REPORT_REMOVE_REPEAT = 3;
	static inline const int REPORT_FINISH = 4;

	class Config
	{
	public:
		unsigned int _max_iteration_step{ 50 };
		unsigned int _n_thread{ 1 };
		unsigned int _population_size{ 64 };
		std::vector<Individual> _seed_individual;
		RepeatType _repeat_removing_type{ RepeatType::Init };
		ConvergeType _convergence_type{ ConvergeType::None };

		// ��Ҫʵ�ֵĽӿڣ�
		virtual void reportGeneration(const std::vector<Individual>& population, const std::vector<double>& cost, int type) const = 0;
		virtual double fitnessMapping(double, const Individual&) const = 0;
		virtual Individual generate() const = 0;
		virtual bool isEqual(const Individual&, const Individual&) const = 0;
		virtual double calculateFitness(const Individual&) const = 0;
		virtual void adjust(Individual&) const = 0;
	};

public:
	struct Solution
	{
		std::vector<double> best_fitness_by_generation, avg_fitness_by_generation, worst_fitness_by_generation;
		Individual value;
		double fitness{ 0 };
	};

	Solution solve(const Config* const config) {
		// �������
		this->_checkConfig(config);

		// ��ʼ��
		this->_init(config, config->_population_size, config->_max_iteration_step, config->_seed_individual);
		config->reportGeneration(_population, _fitness, REPORT_INIT);

		// �������壬ʹ������Լ��
		for (size_t i = 0; i < _population.size(); i++) config->adjust(_population.at(i));
		config->reportGeneration(_population, _fitness, REPORT_ADJUST);

		// ������Ӧ��
		this->_calculate_fitness(config, config->_n_thread);
		config->reportGeneration(_population, _fitness, REPORT_FITNESS);

		// ������Ⱥ����
		this->_calculate_generation_performance();

		// ��ʽ����
		for (size_t iter = 0; iter < config->_max_iteration_step; iter++) {
			// for identify convergence
			double currPerf = 0;
			if (config->_convergence_type == ConvergeType::Best) currPerf = _best_fitness_by_generation.back();
			else if (config->_convergence_type == ConvergeType::Avg) currPerf = _avg_fitness_by_generation.back();

			// �Ż�
			_main_function(config, iter);

			// �������壬ʹ������Լ��
			for (size_t i = 0; i < _population.size(); i++) config->adjust(_population.at(i));
			config->reportGeneration(_population, _fitness, REPORT_ADJUST);

			// ȥ���ظ��ĸ��壬ǿ��ֱ����ͬ�����ܱ�֤��ȫ��ͬ��ֻ�ܸı�֮����ԭ�����غϣ�
			if (config->_repeat_removing_type == RepeatType::Init) this->_change_repeat_chromosome_init(config);
			else if (config->_repeat_removing_type == RepeatType::None);
			else throw frame::exception::bad_param();
			config->reportGeneration(_population, _fitness, REPORT_REMOVE_REPEAT);

			// ������һ������Ӧ��
			this->_calculate_fitness(config, config->_n_thread);
			this->_calculate_generation_performance();
			config->reportGeneration(_population, _fitness, REPORT_FITNESS);

			if (config->_convergence_type != ConvergeType::None) {
				double nextPerf = 0;
				if (config->_convergence_type == ConvergeType::Best) nextPerf = _best_fitness_by_generation.back();
				else if (config->_convergence_type == ConvergeType::Avg) nextPerf = _avg_fitness_by_generation.back();
				if (frame::isConverge(currPerf, nextPerf, std::pow(10,-9))) break;
			}
		}
		config->reportGeneration(_population, _fitness, REPORT_FINISH);
		return this->_output();
	}

protected:
	std::vector<double> _fitness;
	std::vector<double> _best_fitness_by_generation, _worst_fitness_by_generation, _avg_fitness_by_generation;
	std::vector<Individual> _population;
	Individual _opt_val; double _opt_fitness;

	virtual void _main_function(const Config* const config, size_t currIter) = 0;

	virtual bool _checkConfig(const Config* const config) {
		if (!config) throw frame::exception::empty();
		if (config->_n_thread < 1 || config->_n_thread >= 50) throw frame::exception::out_of_range(config->_n_thread, 1, 50);
		if (config->_population_size <= 0) throw frame::exception::out_of_range(config->_population_size, 1, std::pow(10, 9));
		if (config->_max_iteration_step < 0) throw frame::exception::out_of_range(config->_max_iteration_step, 1, std::pow(10, 9));
		return true;
	}

	virtual void _init(const Config* const config, unsigned int popSize, unsigned int maxIterTime, const std::vector<Individual>& seedChromosome) {
		_best_fitness_by_generation.clear(); _best_fitness_by_generation.reserve(maxIterTime + 1);
		_avg_fitness_by_generation.clear(); _avg_fitness_by_generation.reserve(maxIterTime + 1);
		_worst_fitness_by_generation.clear(); _worst_fitness_by_generation.reserve(maxIterTime + 1);
		_population.clear(); _population.reserve(popSize);
		_fitness.clear(); _fitness.reserve(popSize); _fitness.assign(popSize, 0);
		if (seedChromosome.size() >= popSize)
			_population.insert(_population.end(), seedChromosome.begin(), seedChromosome.begin() + popSize);
		else if (seedChromosome.size() == 0)
			for (size_t i = 0; i < popSize; i++) _population.push_back(config->generate());
		else {
			_population.insert(_population.end(), seedChromosome.begin(), seedChromosome.end());
			for (size_t i = 0; i < popSize - seedChromosome.size(); i++) _population.push_back(config->generate());
		}
		this->_opt_fitness = std::pow(10, -9); this->_opt_val = _population.at(0);
	}

	std::vector<double> _calculate_fitness_thread(const Config* const config, size_t threadId, size_t nThread) const {
		std::vector<double> cost;
		size_t size = _population.size();
		for (size_t i = threadId; i < size; i += nThread) {
			double perf = config->calculateFitness(_population.at(i));
			cost.push_back(config->fitnessMapping(perf, _population.at(i)));
		}
		return cost;
	}

	void _calculate_fitness(const Config* const config, unsigned int nThread) {
		if (nThread == 1) {
			for (size_t i = 0; i < _population.size(); i++) {
				_fitness.at(i) = config->calculateFitness(_population.at(i));
				_fitness.at(i) = config->fitnessMapping(_fitness.at(i), _population.at(i));
			}
		}
		else {
			if (nThread > _population.size()) nThread = _population.size();
			if (nThread > ThreadPool::inst().idle()) nThread = ThreadPool::inst().idle();
			std::vector<std::future<std::vector<double>>> results(nThread);
			for (size_t j = 0; j < nThread; j++) {
				results[j] = ThreadPool::inst().commit(std::bind(&MetaHeuristicBase<Individual>::_calculate_fitness_thread, this, config, j, nThread));
			}
			_fitness.clear(); _fitness.assign(_population.size(), 0);
			for (size_t j = 0; j < nThread; j++) {
				std::vector<double> buff = results[j].get();
				for (size_t k = 0; k < buff.size(); k++) _fitness.at(j + k * nThread) = buff.at(k);
			}
		}
	}

	virtual void _calculate_generation_performance() {
		int indMax = std::max_element(_fitness.begin(), _fitness.end()) - _fitness.begin();
		int indMin = std::min_element(_fitness.begin(), _fitness.end()) - _fitness.begin();
		double sumPf = std::accumulate(_fitness.begin(), _fitness.end(), 0.0);
		double bestPf = _fitness.at(indMax); double worstPf = _fitness.at(indMin);
		_avg_fitness_by_generation.push_back(sumPf / _population.size());
		_best_fitness_by_generation.push_back(bestPf);
		_worst_fitness_by_generation.push_back(worstPf);
		if (bestPf > _opt_fitness) {
			_opt_fitness = bestPf; _opt_val = _population.at(indMax);
		}
	}

	void _change_repeat_chromosome_init(const Config* const config) {
		for (size_t i = 0; i < _population.size(); i++) {
			for (size_t j = i + 1; j < _population.size(); j++) {
				if (config->isEqual(_population.at(i), _population.at(j))) {
					_population.at(j) = config->generate();
					config->adjust(_population.at(j));
				}
			}
		}
	}

	Solution _output() {
		Solution solu;
		solu.best_fitness_by_generation = this->_best_fitness_by_generation;
		solu.avg_fitness_by_generation = this->_avg_fitness_by_generation;
		solu.worst_fitness_by_generation = this->_worst_fitness_by_generation;
		solu.fitness = this->_opt_fitness;
		solu.value = _opt_val;
		return solu;
	}
};



}






