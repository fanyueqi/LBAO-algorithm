#pragma once

#include<algorithm>
#include<iterator>
#include"except.h"
#include"number.h"

namespace frame{

template<typename Type>
std::vector<std::string> number_to_string(const std::vector<Type>& ori) {
	if (!isNumber(typeid(Type))) throw exception::type_not_match(typeid(Type).name(), "not a number");
	std::vector<std::string> result; result.reserve(ori.size());
	std::transform(std::begin(ori), std::end(ori), std::back_inserter(result), [](Type in) {return std::to_string(in); });
	return result;
}

template<typename Type>
Type to_number(const std::string& str) {
	if (!isNumber(typeid(Type))) throw exception::type_not_match(typeid(Type).name(), "not a number");
	if (typeid(Type) == typeid(int)) return std::stoi(str);
	else if (typeid(Type) == typeid(double)) return std::stod(str);
}

template<typename Type>
std::vector<Type> to_number(const std::vector<std::string>& strList) {
	std::vector<Type> res; res.reserve(strList.size());
	for (size_t i = 0; i < strList.size(); i++) res.push_back(to_number<Type>(strList.at(i)));
	return res;
}

template<typename Type>
std::vector<std::vector<Type>> to_number(const std::vector<std::vector<std::string>>& strList) {
	std::vector<std::vector<Type>> res; res.reserve(strList.size());
	for (size_t i = 0; i < strList.size(); i++) res.push_back(to_number<Type>(strList.at(i)));
	return res;
}

template<typename Type>
void serialization(const XVector<std::string, std::vector<Type>>& data, const std::vector<std::string>& nameOrder, std::vector<Type>& result) {
	if (isNumber(typeid(Type))) {
		if (data.size() != nameOrder.size()) throw exception::size_not_match(data.size(), nameOrder.size());
		size_t total = 0; for (size_t i = 0; i < data.size(); i++) total += data.at(i).size();
		result.clear(); result.reserve(total);
		for (size_t i = 0; i < data.size(); i++) result.insert(result.end(), data.find(nameOrder.at(i)).begin(), data.find(nameOrder.at(i)).end());
	}
	else throw exception::type_not_match(typeid(Type).name(), "not a number");
}

template<typename Type>
void deserialization(const std::vector<Type>& data, const std::vector<size_t>& sizeOfEach, const std::vector<std::string>& nameList, XVector<std::string, std::vector<Type>>& result) {
	if (isNumber(typeid(Type))) {
		if (sizeOfEach.size() != nameList.size()) throw exception::size_not_match(sizeOfEach.size(), nameList.size());
		size_t total = 0; for (size_t i = 0; i < sizeOfEach.size(); i++) total += sizeOfEach.at(i);
		if (total != data.size()) throw exception::size_not_match(total, data.size());
		result.clear(); size_t start = 0;
		for (size_t i = 0; i < sizeOfEach.size(); i++) {
			result.add(nameList.at(i), std::vector<Type>(data.begin() + start, data.begin() + start + sizeOfEach.at(i)));
			start += start + sizeOfEach.at(i);
		}
	}
	else throw exception::type_not_match(typeid(Type).name(), "not a number");
}

}