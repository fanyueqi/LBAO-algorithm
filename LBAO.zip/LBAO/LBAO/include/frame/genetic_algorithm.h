#pragma once

#include <numeric>
#include"meta_heuristic_base.h"
#include"rand.h"

namespace frame {

/*
* Chromosome����Ҫʵ����ȹ��캯���Լ�=�����
* ֻ�������
*/

template<typename Chromosome>
class GeneticAlgorithm : public MetaHeuristicBase<Chromosome>
{
public:
	enum class SelectType { Wheel };
	enum class WheelType { Rank }; // ��δ���Ӧ�ȼ������̵ķ�ʽ
	enum class ParentType { Optimal, Wheel }; // ѡ��ĸ�ķ�ʽ
	enum class CrossoverType { UniformReplace, UniformArithmetic, PiecewiseReplace };

	static inline const int REPORT_SELECTION = 5;
	static inline const int REPORT_CROSSOVER = 6;
	static inline const int REPORT_MUTATION = 7;

	class Config : public MetaHeuristicBase<Chromosome>::Config {
	public:
		SelectType _select_type{ SelectType::Wheel };
		WheelType _wheel_type{ WheelType::Rank }; // ֻ�����������
		double _elite_proportion{ 0.2 }; // ÿ�����ȱ����ľ�Ӣ������ֻ����wheel��������AP�����ͺ�ľ�Ӣ��Ȼ�����������
		ParentType _parent_type{ ParentType::Wheel };
		CrossoverType _crossover_type{ CrossoverType::UniformReplace };
		double _crossover_ratio{ 1 };
		double _crossover_probability{ 0.4 }; // ���Ƚ���ĸ��� �� ��ν��������
		double _mutation_probability{ 0.05 };

		// ��Ҫʵ�ֵĽӿڣ�
		virtual void crossover(CrossoverType type, Chromosome& a, Chromosome& b, double probability) const = 0;
		virtual void mutation(Chromosome& a, double probability, const Chromosome& templateChromosome) const = 0;
		virtual void reportGeneration(const std::vector<Chromosome>& population, const std::vector<double>& cost, int type) const = 0;
		virtual double fitnessMapping(double, const Chromosome&) const = 0;
		virtual Chromosome generate() const = 0;
		virtual bool isEqual(const Chromosome&, const Chromosome&) const = 0;
		virtual double calculateFitness(const Chromosome&) const = 0;
		virtual void adjust(Chromosome&) const = 0;
	};

	//struct Solution {
		//std::vector<double> best_fitness_by_generation, avg_fitness_by_generation, worst_fitness_by_generation;
		//Individual value; double fitness{ 0 };
	//};

	//Solution solve(const Config* const config);

	// 
	//
	//
	//
	// ����Ĵ��벻��Ҫ��
	//
	//
	//
	//
	//
protected:
	// �������
	bool _checkConfig(const MetaHeuristicBase<Chromosome>::Config* const __config) override {
		MetaHeuristicBase<Chromosome>::_checkConfig(__config);
		const Config* const config = dynamic_cast<Config*>(const_cast<MetaHeuristicBase<Chromosome>::Config*>(__config));
		if (config->_select_type == SelectType::Wheel)
			if (config->_elite_proportion < 0 || config->_elite_proportion>1) throw frame::exception::out_of_range(config->_elite_proportion, 0, 1);
		if (config->_crossover_ratio <= 0 || config->_crossover_ratio > 1) throw frame::exception::out_of_range(config->_crossover_ratio, 0, 1);
		if (config->_crossover_probability < 0 || config->_crossover_probability>1) frame::exception::out_of_range(config->_crossover_probability, 0, 1);
		if (config->_mutation_probability < 0 || config->_mutation_probability>1) frame::exception::out_of_range(config->_mutation_probability, 0, 1);
		return true;
	}

	// �ڼ������ڵı�ţ��ɴ�С
	std::vector<size_t> _get_fitness_sorted_index() {
		std::vector<size_t> fitness_sorted_index(this->_population.size());
		std::iota(fitness_sorted_index.begin(), fitness_sorted_index.end(), 0);
		const std::vector<double>& ref = this->_fitness;
		std::sort(fitness_sorted_index.begin(), fitness_sorted_index.end(),
			[&ref](size_t i1, size_t i2) {return ref.at(i1) > ref.at(i2); });
		return fitness_sorted_index;
	}

	// ���ص��ۼӸ���
	std::vector<double> _get_wheel(WheelType type) {
		std::vector<double> wheel(this->_population.size());
		if (type == WheelType::Rank) {
			std::vector<size_t> fitness_sorted_index = _get_fitness_sorted_index();
			std::vector<double> cost(this->_population.size());
			for (size_t i = 0; i < this->_population.size(); i++) {
				cost.at(fitness_sorted_index.at(i)) = 1 / sqrt(1 + i);
			}
			wheel.at(0) = cost.at(0);
			for (size_t i = 1; i < this->_population.size(); i++) wheel.at(i) = wheel.at(i - 1) + cost.at(i);
			// ��һ��
			for (size_t i = 0; i < this->_population.size(); i++) wheel.at(i) = wheel.at(i) / wheel.back();
			return wheel;
		}
		else throw frame::exception::bad_param();
	}

	// ���ر��
	size_t _play_wheel(const std::vector<double>& wheel, double probability) {
		for (size_t i = 0; i < wheel.size(); i++) if (probability < wheel.at(i)) return i;
	}

	void _selection_wheel(const Config* const ga, double eliteProportion, WheelType wheelType) {
		std::vector<Chromosome> newPopulation; newPopulation.reserve(this->_population.size());
		std::vector<double> newFitness; newFitness.reserve(this->_population.size());

		// �ȱ��;�Ӣ
		int nElite = this->_population.size() * eliteProportion;
		std::vector<size_t> fitness_sorted_index = _get_fitness_sorted_index(); // ����Ⱥÿ���������Ӧ�����򣨴Ӵ�С��
		for (size_t i = 0; i < nElite; i++) {
			size_t ind = fitness_sorted_index.at(i);
			newPopulation.push_back(this->_population.at(ind));
			newFitness.push_back(this->_fitness.at(ind));
		}

		// �����������
		std::vector<double> wheel = _get_wheel(wheelType);
		for (size_t i = nElite; i < this->_population.size(); i++) {
			double r = frame::randd(0, 0.999);
			size_t ind = _play_wheel(wheel, r);
			newPopulation.push_back(this->_population.at(ind));
			newFitness.push_back(this->_fitness.at(ind));
		}

		// �����һ��
		this->_population = newPopulation;
		this->_fitness = newFitness;
	}

	void _crossover_wheel_parent(const Config* const ga, CrossoverType type, double ratio, double probability, WheelType wheelType) {
		// һ��Ҫ��(int) (popSize/2) �ν���
		int nCross = this->_population.size() * ratio / 2;
		std::vector<double> wheel = _get_wheel(wheelType);
		for (size_t i = 0; i < nCross; i++) {
			Chromosome& c1 = this->_population.at(_play_wheel(wheel, frame::randd(0, 0.999)));
			Chromosome& c2 = this->_population.at(_play_wheel(wheel, frame::randd(0, 0.999)));
			ga->crossover(type, c1, c2, probability);
		}
	}

	void _crossover_optimal_parent(const Config* const ga, CrossoverType type, double ratio, double probability) {
		// һ��Ҫ��(int) (popSize/2) �ν���
		int nCross = this->_population.size() * ratio / 2;
		std::vector<size_t> fitness_sorted_index = _get_fitness_sorted_index();
		for (size_t i = 0; i < nCross; i++) {
			Chromosome& c1 = this->_population.at(fitness_sorted_index.at(i * 2));
			Chromosome& c2 = this->_population.at(fitness_sorted_index.at(i * 2 + 1));
			ga->crossover(type, c1, c2, probability);
		}
	}

	void _main_function(const MetaHeuristicBase<Chromosome>::Config* const __config, size_t) override {
		const Config* const config = dynamic_cast<Config*>(const_cast<MetaHeuristicBase<Chromosome>::Config*>(__config));

		// selection
		if (config->_select_type == SelectType::Wheel)
			this->_selection_wheel(config, config->_elite_proportion, config->_wheel_type);
		else throw frame::exception::bad_param();
		config->reportGeneration(this->_population, this->_fitness, REPORT_SELECTION);

		// crossover
		if (config->_parent_type == ParentType::Wheel)
			this->_crossover_wheel_parent(config, config->_crossover_type, config->_crossover_ratio, config->_crossover_probability, config->_wheel_type);
		else if (config->_parent_type == ParentType::Optimal)
			this->_crossover_optimal_parent(config, config->_crossover_type, config->_crossover_ratio, config->_crossover_probability);
		else  throw frame::exception::bad_param();
		config->reportGeneration(this->_population, this->_fitness, REPORT_CROSSOVER);

		// mutation
		for (size_t i = 0; i < this->_population.size(); i++) {
			Chromosome templateChromosome = config->generate();
			config->mutation(this->_population.at(i), config->_mutation_probability, templateChromosome);
		}
		config->reportGeneration(this->_population, this->_fitness, REPORT_MUTATION);
	}




};




}

