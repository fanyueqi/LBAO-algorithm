#pragma once

#include<vector>
#include<functional>
#include"xvector.h"
#include"function.h"
#include<boost/numeric/odeint/stepper/euler.hpp>
#include<boost/numeric/odeint/stepper/runge_kutta4.hpp>
#include"toolkit.h"
#include<optional>

namespace frame{

template<typename Param, typename FunctionType, typename ValueType, typename TraceType>
class ODETimeMarchingSolver
{
public:
	enum class SolverType { Euler, RungeKutta4 }; // ����û���𣬵�����ʱ����Զ
	using DiffRule = std::function<XVector<std::string, ValueType>(const Param&, const XVector<std::string, ValueType>& base, double t)>;
	using ImpRule = std::function<XVector<std::string, ValueType>(const Param&, const XVector<std::string, ValueType>& base, size_t tInd)>;
	using Function = Function<FunctionType, ValueType, TraceType>;

	ODETimeMarchingSolver(Function& func, const Param& para, DiffRule diff, ImpRule imp,
		const std::vector<double>& time, const std::vector<double>& imptime, SolverType type = SolverType::Euler)
		: _func(func), _diffRule(diff), _impRule(imp), _solverType(type), _time(time), _imp_time(imptime), _param(para)
	{
		// do nothing
	}
	void forward_one_step(size_t t) const {
		if (t >= _func.nTime() - 1) throw exception::out_of_range(t, 0, _func.nTime() - 1);

		_func.setValueAtTime(_func.getValueAtTime(t), t + 1, "=");

		// ����
		if (_impRule && hasElement(_imp_time, _time.at(t), _time.at(t+1))) {
			_func.setValueAtTime(_impRule(_param, _func.getValueAtTime(t), t), t + 1, "+=");
		}
		for (size_t i = 0; i < _func.size(); i++) _func.forceInBoundary(i, t + 1);

		if (!_diffRule) return;

		// ����
		double h = _time.at(t + 1) - _time.at(t); 
		DiffRuleCallBack rule(_func, _diffRule, _param);
		std::vector<double> base; serialization(_func.getValueAtTime(t + 1), _func.getName(), base);
		if (_solverType == SolverType::Euler) {
			boost::numeric::odeint::euler<std::vector<double>> euler;
			euler.do_step(rule, base, _time.at(t), h);
		}
		else if (_solverType == SolverType::RungeKutta4) {
			boost::numeric::odeint::runge_kutta4<std::vector<double>> runge;
			runge.do_step(rule, base, _time.at(t), h);
		}
		else throw exception::bad_param();
		XVector<std::string, std::vector<double>> res; deserialization(base, _func.nDim(), _func.getName(), res);
		_func.setValueAtTime(res, t + 1, "=");
		for (size_t i = 0; i < _func.size(); i++) _func.forceInBoundary(i, t + 1);
	}
	void forward_range(std::optional<size_t> start, std::optional<size_t> end)  const { //[start,end)
		size_t tstart = 0, tend = _func.nTime() - 1;
		if (start) tstart = *start; if (end) tend = *end;
		if (tstart >= tend) throw exception::bad_range(std::to_string(tstart), std::to_string(tend));
		if (tend > _func.nTime() - 1) throw exception::out_of_range(tend, 0, _func.nTime() - 1);
		for (size_t t = tstart; t < tend; t++)  forward_one_step(t);
	}
	void forward_whole() const {
		forward_range(std::nullopt, std::nullopt);
	}

private:
	const Param& _param;
	std::vector<double> _time;
	std::vector<double> _imp_time;
	Function& _func;
	DiffRule _diffRule{ nullptr };
	ImpRule _impRule{ nullptr };
	SolverType _solverType{ SolverType::Euler };

	class DiffRuleCallBack {
		const Function& _func; DiffRule _rule; const Param& _para;
	public:
		DiffRuleCallBack(const Function& func, DiffRule rule, const Param& para) : _rule(rule), _func(func), _para(para) {}
		void operator()(const std::vector<double>& base, std::vector<double>& diff, const double t) const {
			XVector<std::string, std::vector<double>> state;
			deserialization(base, _func.nDim(), _func.getName(), state);
			serialization(_rule(_para, state, t), _func.getName(), diff);
		}
	};
};

}