
#include"toolkit.h"
#include <numeric>

namespace mf = frame;

bool frame::isNumber(const std::type_info& type){
	if (type != typeid(int) && type != typeid(double)) return false;
	return true;
}

bool frame::isInt(double x) {
	double e = pow(10,-6);
	if (x - (int)x < e || (int)(x + 1) - x < e) return true;
	else return false;
}

int frame::getPreciseInt(double x) {
	double e = pow(10, -6);
	if (x - (int)x < e) return (int)x;
	else if ((int)(x + 1) - x < e) return (int)(x + 1);
	else throw exception::type_not_match(std::to_string(x), "integer");
}

int frame::getPreciseCeil(double x) {
	if (isInt(x)) return getPreciseInt(x);
	else return getPreciseInt(ceil(x));
}

bool frame::isConverge(double last, double curr, double error) {
    bool val = true;
    if (std::abs(last) <= error) {
        if (std::abs(curr) > 2 * error)
            val = false;
        return val;
    }

    // last != 0
    if (last > 0) {
        if (std::abs(curr - last) / last > error) val = false;
    }
    else if (last < 0) {
        if (std::abs(curr - last) / -last > error) val = false;
    }

    return val;
}

bool frame::isConverge(const std::vector<double>& last, const std::vector<double>& curr, double epsilon) {
    bool val = true;
    if (last.size() != curr.size()) throw frame::exception::size_not_match(last.size(), curr.size());

    for (int i = 0; i < last.size(); i++) {
        bool sub = isConverge(last.at(i), curr.at(i), epsilon);
        val = val && sub;
    }

    return val;
}

std::vector<size_t> frame::sort(const std::vector<double>& target, bool increasing) {
    std::vector<size_t> ind(target.size());
    std::iota(ind.begin(), ind.end(), 0);
    if (increasing) {
        auto rule = [target](int i, int j)->bool {
            return target[i] < target[j];
        };//�������ʽ����Ϊsort��ν��
        std::sort(ind.data(), ind.data() + ind.size(), rule);
    }
    else {
        auto rule = [target](int i, int j)->bool {
            return target[i] > target[j];
        };//�������ʽ����Ϊsort��ν��
        std::sort(ind.data(), ind.data() + ind.size(), rule);
    }
    return ind;
}

std::string frame::totalRunTime(std::clock_t start, std::clock_t end) {
    if (end < start) throw exception::bad_range(std::to_string(start), std::to_string(end));
    double cTotolTime = (double)(end - start) / CLOCKS_PER_SEC;
    if (cTotolTime >= 60 && cTotolTime < 3600) {
        int min = cTotolTime / 60;
        double sec = cTotolTime - min * 60;
        return "run time: " + std::to_string(min) + "m " + std::to_string(sec) + "s";
    }
    else if (cTotolTime >= 3600) {
        int hour = cTotolTime / 3600;
        int min = (cTotolTime - hour * 3600) / 60;
        double sec = cTotolTime - hour * 3600 - min * 60;
        return "run time: " + std::to_string(hour) + "h " + std::to_string(min) + "m " + std::to_string(sec) + "s";
    }
    else if (cTotolTime < 60) {
        return "run time: " + std::to_string(cTotolTime) + "s";
    }
    else return "error";
}
