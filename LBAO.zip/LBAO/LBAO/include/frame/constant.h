#pragma once

#include"except.h"

namespace frame{

template<typename IVec, typename DVec, typename IMat, typename DMat, typename ISuMat, typename DSuMat>
class Constant
{
public:
	Constant(const std::type_info& type) : _type(type.name()) {}
	Constant(const std::string& val) : _type(typeid(std::string).name()) { _sVal = val; }
	Constant(const int& val) : _type(typeid(int).name()) { _iVal = val; }
	Constant(const double& val) : _type(typeid(double).name()) { _dVal = val; }
	Constant(const IVec& val) : _type(typeid(IVec).name()) { _iVec = val; }
	Constant(const DVec& val) : _type(typeid(DVec).name()) { _dVec = val; }
	Constant(const IMat& val) : _type(typeid(IMat).name()) { _iMat = val; }
	Constant(const DMat& val) : _type(typeid(DMat).name()) { _dMat = val; }
	Constant(const ISuMat& val) : _type(typeid(ISuMat).name()) { _iSuMat = val; }
	Constant(const DSuMat& val) : _type(typeid(DSuMat).name()) { _dSuMat = val; }

	const std::string& sVal() const { if (_type == typeid(std::string).name()) return _sVal; else throw exception::type_not_match(_type, typeid(std::string).name()); }
	std::string& sVal() { return const_cast<std::string&>(std::as_const(*this).sVal()); }
	Constant& operator=(const std::string& val) { this->sVal() = val; return *this; }

	const int& iVal() const { if (_type == typeid(int).name()) return _iVal; else throw exception::type_not_match(_type, typeid(int).name()); }
	int& iVal() { return const_cast<int&>(std::as_const(*this).iVal()); }
	Constant& operator=(const int& val) { this->dVal() = val; return *this; }

	const double& dVal() const { if (_type == typeid(double).name()) return _dVal; else throw exception::type_not_match(_type, typeid(double).name()); }
	double& dVal() { return const_cast<double&>(std::as_const(*this).dVal()); }
	Constant& operator=(const double& val) { this->dVal() = val; return *this; }

	const IVec& iVec() const { if (_type == typeid(IVec).name()) return _iVec; else throw exception::type_not_match(_type, typeid(IVec).name()); }
	IVec& iVec() { return const_cast<IVec&>(std::as_const(*this).iVec()); }
	Constant& operator=(const IVec& val) { this->iVec() = val; return *this; }

	const DVec& dVec() const { if (_type == typeid(DVec).name()) return _dVec; else throw exception::type_not_match(_type, typeid(DVec).name()); }
	DVec& dVec() { return const_cast<DVec&>(std::as_const(*this).dVec()); }
	Constant& operator=(const DVec& val) { this->dVec() = val; return *this; }

	const IMat& iMat() const { if (_type == typeid(IMat).name()) return _iMat; else throw exception::type_not_match(_type, typeid(IMat).name()); }
	IMat& iMat() { return const_cast<IMat&>(std::as_const(*this).iMat()); }
	Constant& operator=(const IMat& val) { this->iMat() = val; return *this; }

	const DMat& dMat() const { if (_type == typeid(DMat).name()) return _dMat; else throw exception::type_not_match(_type, typeid(DMat).name()); }
	DMat& dMat() { return const_cast<DMat&>(std::as_const(*this).dMat()); }
	Constant& operator=(const DMat& val) { this->dMat() = val; return *this; }

	const ISuMat& iSuMat() const { if (_type == typeid(ISuMat).name()) return _iSuMat; else throw exception::type_not_match(_type, typeid(ISuMat).name()); }
	ISuMat& iSuMat() { return const_cast<ISuMat&>(std::as_const(*this).iSuMat()); }
	Constant& operator=(const ISuMat& val) { this->iSuMat() = val; return *this; }

	const DSuMat& dSuMat() const { if (_type == typeid(DSuMat).name()) return _dSuMat; else throw exception::type_not_match(_type, typeid(DSuMat).name()); }
	DSuMat& dSuMat() { return const_cast<DSuMat&>(std::as_const(*this).dSuMat()); }
	Constant& operator=(const DSuMat& val) { this->dSuMat() = val; return *this; }

private:
	std::string _type;
	std::string _sVal;
	int _iVal{ 0 };
	double _dVal{ 0 };
	IVec _iVec;
	DVec _dVec;
	IMat _iMat;
	DMat _dMat;
	ISuMat _iSuMat;
	DSuMat _dSuMat;
};

template<typename IVec, typename DVec, typename IMat, typename DMat, typename ISuMat, typename DSuMat>
class Constant_ReadOnly
{
public:
	using Type = Constant<IVec, DVec, IMat, DMat, ISuMat, DSuMat>;

	Constant_ReadOnly(const Type& data) : _data(data) {}

	const std::string& sVal() const { return _data.sVal(); }
	const int& iVal() const { return _data.iVal(); }
	const double& dVal() const { return _data.dVal(); }
	const IVec& iVec() const { return _data.iVec(); }
	const DVec& dVec() const { return _data.dVec(); }
	const IMat& iMat() const { return _data.iMat(); }
	const DMat& dMat() const { return _data.dMat(); }
	const ISuMat& iSuMat() const { return _data.iSuMat(); }
	const DSuMat& dSuMat() const { return _data.dSuMat(); }

private:
	const Type& _data;
};

}