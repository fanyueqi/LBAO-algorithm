#pragma once

#include<vector>
#include<typeinfo>

namespace frame{

bool isNumber(const std::type_info& type);
bool isInt(double val);
int getPreciseInt(double val);
int getPreciseCeil(double val);
bool isConverge(double last, double curr, double error);
bool isConverge(const std::vector<double>& last, const std::vector<double>& curr, double epsilon);

}
