#pragma once

#include"number.h"
#include"except.h"
#include"xvector.h"

namespace frame{

template<typename Type>
std::vector<Type> abs(const std::vector<Type>& arr) {
	if (isNumber(typeid(Type))) {
		std::vector<Type> res; res.reserve(arr.size());
		for (const Type& val : arr) res.push_back(std::abs(val));
		return res;
	}
	else throw exception::type_not_match(typeid(Type).name(), "not a number");
}

template<typename ConstType, typename ArrType>
std::vector<ArrType> eval(const std::vector<ArrType>& a, const ConstType& b, char sign) {
	if (isNumber(typeid(ArrType)) || isNumber(typeid(ConstType))) {
		std::vector<ArrType> res; res.reserve(a.size());
		if (sign == '+') for (size_t i = 0; i < a.size(); i++) res.push_back(a.at(i) + b);
		else if (sign == '-') for (size_t i = 0; i < a.size(); i++) res.push_back(a.at(i) - b);
		else if (sign == '*') for (size_t i = 0; i < a.size(); i++) res.push_back(a.at(i) * b);
		else if (sign == '/') for (size_t i = 0; i < a.size(); i++) res.push_back(a.at(i) / b);
		else throw frame::exception::bad_symbol(sign);
		return res;
	}
	else throw exception::type_not_match(std::string(typeid(ArrType).name())+"|"+ std::string(typeid(ConstType).name()), "not a number");
}

template<typename ConstType, typename ArrType>
std::vector<ArrType> operator+(const ConstType& b, const std::vector<ArrType>& a) {
	return eval(a, b, '+');
}

template<typename ConstType, typename ArrType>
std::vector<ArrType> operator-(const ConstType& b, const std::vector<ArrType>& a) {
	return eval(a, b, '-');
}

template<typename ConstType, typename ArrType>
std::vector<ArrType> operator*(const ConstType& b, const std::vector<ArrType>& a) {
	return eval(a, b, '*');
}

template<typename ConstType, typename ArrType>
std::vector<ArrType> operator/(const std::vector<ArrType>& a, const ConstType& b) {
	return eval(a, b, '/');
}

template<typename Type>
std::vector<Type> eval(const std::vector<Type>& a, const std::vector<Type>& b, char sign) {
	if (isNumber(typeid(Type))) {
		if (a.size() != b.size()) throw exception::size_not_match(a.size(), b.size());
		std::vector<Type> res; res.reserve(a.size());
		if (sign == '+') for (size_t i = 0; i < a.size(); i++) res.push_back(a.at(i) + b.at(i));
		else if (sign == '-') for (size_t i = 0; i < a.size(); i++) res.push_back(a.at(i) - b.at(i));
		else if (sign == '*') for (size_t i = 0; i < a.size(); i++) res.push_back(a.at(i) * b.at(i));
		else if (sign == '/') for (size_t i = 0; i < a.size(); i++) res.push_back(a.at(i) / b.at(i));
		else throw exception::bad_symbol(sign);
		return res;
	}
	else throw exception::type_not_match(typeid(Type).name(), "not a number");
}

template<typename Type>
std::vector<Type>& self_eval(std::vector<Type>& a, const std::vector<Type>& b, const std::string& sign) {
	if (isNumber(typeid(Type))) {
		if (a.size() != b.size()) throw exception::size_not_match(a.size(), b.size());
		if (sign == "+=") for (size_t i = 0; i < a.size(); i++) a.at(i) += b.at(i);
		else if (sign == "-=") for (size_t i = 0; i < a.size(); i++) a.at(i) -= b.at(i);
		else if (sign == "*=") for (size_t i = 0; i < a.size(); i++) a.at(i) *= b.at(i);
		else if (sign == "/=") for (size_t i = 0; i < a.size(); i++) a.at(i) /= b.at(i);
		else throw frame::exception::bad_symbol(sign);
		return a;
	}
	else throw exception::type_not_match(typeid(Type).name(), "not a number");
}

template<typename Type>
std::vector<Type> operator+(const std::vector<Type>& a, const std::vector<Type>& b) {
	return eval(a, b, '+');
}

template<typename Type>
std::vector<Type> operator-(const std::vector<Type>& a, const std::vector<Type>& b) {
	return eval(a, b, '-');
}

template<typename Type>
std::vector<Type> operator*(const std::vector<Type>& a, const std::vector<Type>& b) {
	return eval(a, b, '*');
}

template<typename Type>
std::vector<Type> operator/(const std::vector<Type>& a, const std::vector<Type>& b) {
	return eval(a, b, '/');
}

template<typename Type>
std::vector<Type>& operator+=(std::vector<Type>& a, const std::vector<Type>& b) {
	return self_eval(a, b, "+=");
}

template<typename Type>
std::vector<Type>& operator-=(std::vector<Type>& a, const std::vector<Type>& b) {
	return self_eval(a, b, "-=");
}

template<typename Type>
std::vector<Type>& operator*=(std::vector<Type>& a, const std::vector<Type>& b) {
	return self_eval(a, b, "*=");
}

template<typename Type>
std::vector<Type>& operator/=(std::vector<Type>& a, const std::vector<Type>& b) {
	return self_eval(a, b, "/=");
}

template<typename Type>
XVector<std::string, std::vector<Type>> eval(const XVector<std::string, std::vector<Type>>& a, const XVector<std::string, std::vector<Type>>& b, char sign) {
	if (isNumber(typeid(Type))) {
		if (a.size() != b.size()) throw size_not_match(a.size(), b.size());
		XVector<std::string, std::vector<Type>> res;
		if (sign == '+')  for (size_t i = 0; i < a.size(); i++) res.add(a.key(i), a.at(i) + b.find(a.key(i)));
		else if (sign == '-') for (size_t i = 0; i < a.size(); i++) res.add(a.key(i), a.at(i) - b.find(a.key(i)));
		else if (sign == '*') for (size_t i = 0; i < a.size(); i++) res.add(a.key(i), a.at(i) * b.find(a.key(i)));
		else if (sign == '/') for (size_t i = 0; i < a.size(); i++) res.add(a.key(i), a.at(i) / b.find(a.key(i)));
		else throw frame::exception::bad_symbol(std::string(sign));
		return res;
	}
	else throw type_not_match(typeid(Type).name(), "not a number");
}

template<typename Type>
XVector<std::string, std::vector<Type>>& self_eval(XVector<std::string, std::vector<Type>>& a, const XVector<std::string, std::vector<Type>>& b, const std::string& sign) {
	if (isNumber(typeid(Type))) {
		if (a.size() != b.size()) throw size_not_match(a.size(), b.size());
		if (sign == "+=") for (size_t i = 0; i < a.size(); i++) a.at(i) += b.find(a.key(i));
		else if (sign == "-=")  for (size_t i = 0; i < a.size(); i++) a.at(i) -= b.find(a.key(i));
		else if (sign == "*=")  for (size_t i = 0; i < a.size(); i++) a.at(i) *= b.find(a.key(i));
		else if (sign == "/=")  for (size_t i = 0; i < a.size(); i++) a.at(i) /= b.find(a.key(i));
		else throw frame::exception::bad_symbol(sign);
		return a;
	}
	else throw type_not_match(typeid(Type).name(), "not a number");
}

template<typename Type>
XVector<std::string, std::vector<Type>> operator+(const XVector<std::string, std::vector<Type>>& a, const XVector<std::string, std::vector<Type>>& b) {
	return eval(a, b, "+");
}

template<typename Type>
XVector<std::string, std::vector<Type>> operator-(const XVector<std::string, std::vector<Type>>& a, const XVector<std::string, std::vector<Type>>& b) {
	return eval(a, b, "-");
}

template<typename Type>
XVector<std::string, std::vector<Type>> operator*(const XVector<std::string, std::vector<Type>>& a, const XVector<std::string, std::vector<Type>>& b) {
	return eval(a, b, "*");
}

template<typename Type>
XVector<std::string, std::vector<Type>> operator/(const XVector<std::string, std::vector<Type>>& a, const XVector<std::string, std::vector<Type>>& b) {
	return eval(a, b, "/");
}

template<typename Type>
XVector<std::string, std::vector<Type>>& operator+=(XVector<std::string, std::vector<Type>>& a, const XVector<std::string, std::vector<Type>>& b) {
	return self_eval(a, b, "+=");
}

template<typename Type>
XVector<std::string, std::vector<Type>>& operator-=(XVector<std::string, std::vector<Type>>& a, const XVector<std::string, std::vector<Type>>& b) {
	return self_eval(a, b, "-=");
}

template<typename Type>
XVector<std::string, std::vector<Type>>& operator*=(XVector<std::string, std::vector<Type>>& a, const XVector<std::string, std::vector<Type>>& b) {
	return self_eval(a, b, "*=");
}

template<typename Type>
XVector<std::string, std::vector<Type>>& operator/=(XVector<std::string, std::vector<Type>>& a, const XVector<std::string, std::vector<Type>>& b) {
	return self_eval(a, b, "/=");
}

}