#pragma once

#include<stdexcept>
#include <string>
#include<typeinfo>

namespace frame {
namespace exception{

class find_no_element : public std::logic_error
{
public:
	find_no_element(const std::string& key) : std::logic_error("find no element: " + key) {}
	find_no_element(const std::string& containerType, const std::string& key, const std::string& containerName)
		: std::logic_error(containerType + ": find no element " + key + " from " + containerName) {}
	find_no_element(const std::string& key, const std::string& containerName)
		: std::logic_error("find no element: " + key + " from " + containerName) {}
};

class size_not_match : public std::logic_error
{
public:
	size_not_match(const std::string& containerNameA, size_t sizeOfA, const std::string& containerNameB, size_t sizeOfB)
		: std::logic_error("size not match: sizeof(" + containerNameA + ")=" + std::to_string(sizeOfA) + ", sizeof(" + containerNameB + ")=" + std::to_string(sizeOfB)) {}
	size_not_match(size_t sizeOfA, size_t sizeOfB) : std::logic_error("size not match: " + std::to_string(sizeOfA) + " != " + std::to_string(sizeOfB)) {}
	size_not_match(size_t sizeOfA, size_t sizeOfB, size_t sizeOfC) : std::logic_error("size not match: " + std::to_string(sizeOfA) + "," + std::to_string(sizeOfB)+","+ std::to_string(sizeOfC)) {}
	size_not_match() : std::logic_error("size not match") {}
};

template<typename TypeA, typename TypeB, typename TypeC>
class out_of_range : public std::logic_error
{
public:
	out_of_range(TypeA currVal, TypeB minVal, TypeC maxVal)
		: std::logic_error("out of range: " + std::to_string(currVal) + " from [" + std::to_string(minVal) + "," + std::to_string(maxVal) + "]") {}
};

class bad_range : public std::logic_error
{
public:
	bad_range(const std::string& leftBound, const std::string& rightBound) : std::logic_error("bad range: " + leftBound + "," + rightBound) {}
};

class type_not_match : public std::logic_error
{
public:
	type_not_match(const std::string& typeA, const std::string& typeB)
		: std::logic_error("type not match: " + typeA + ", " + typeB) {}
};

class bad_symbol : public std::logic_error
{
public:
	bad_symbol(const std::string& symbol): std::logic_error("bad symbol: " + symbol){}
	bad_symbol(char symbol) : std::logic_error("bad symbol: " + symbol) {}
};

class bad_param : public std::logic_error
{
public:
	bad_param() : std::logic_error("bad parameter") {}
};

class empty : public std::logic_error
{
public:
	empty() : std::logic_error("empty function/data") {}
};

class file_open_failure: public std::logic_error
{
public:
	file_open_failure(const std::string& filename) : std::logic_error("file open failure: "+ filename) {}
};

class repeated_element: public std::logic_error
{
public:
	repeated_element(const std::string& element, const std::string& container) : std::logic_error("repeated elements: " + element +" in " + container) {}
};

class unknown : public std::logic_error
{
public:
	unknown() : std::logic_error("unkonwn error") {}
};

class has_reduplicative_element : public std::logic_error
{
public:
	has_reduplicative_element(const std::string& element) : std::logic_error("has reduplicative elements: " + element) {}
};

}
}