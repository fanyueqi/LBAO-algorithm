#pragma once

#include"operator.h"
#include"typeconvert.h"
#include<ctime>
#include <set>

namespace frame{

std::vector<size_t> sort(const std::vector<double>& target, bool increasing); // return index list
std::string totalRunTime(std::clock_t start, std::clock_t end);

template<typename Type>
bool hasElement(const std::vector<Type>& arr, const Type& start, const Type& end) {
	if (!isNumber(typeid(Type))) throw exception::type_not_match(typeid(Type).name(), "not a number");
	if (start > end) throw exception::bad_range(std::to_string(start), std::to_string(end));
	for (size_t j = 0; j < arr.size(); j++) if (start <= arr.at(j) && arr.at(j) < end) return true;
	return false;
}

template<typename Type>
bool hasSimilar(const Type& val, const std::vector<Type>& arr, double error) {
	if (!isNumber(typeid(Type))) throw exception::type_not_match(typeid(Type).name(), "not a number");
	for (size_t i = 0; i < arr.size(); i++) if (std::abs(val - arr.at(i)) < error) return true;
	return false;
}

template<typename Type>
bool hasRepeat(const std::vector<Type>& arr) {
	std::set<Type> temp(arr.begin(), arr.end());
	return arr.size() != temp.size();
}

template<typename Type>
void rearrange(const std::vector<size_t>& index, std::vector<Type>& arr) {
	if (arr.size() != index.size()) throw exception::size_not_match(index.size(), arr.size());
	auto buff = arr;
	for (size_t i = 0; i < index.size(); i++) arr.at(i) = buff.at(index.at(i));
}

template<typename Type>
static std::string combine_to_string(const std::vector<Type>& ori, std::string gap) {
	if (!isNumber(typeid(Type))) throw exception::type_not_match(typeid(Type).name(), "not a number");
	std::string buff = "";
	for (size_t i = 0; i < ori.size(); i++) {
		buff += std::to_string(ori.at(i));
		if (i != ori.size() - 1) buff += gap;
	}
	return buff;
}

template<typename Type>
static std::vector<std::string> combine_to_string_multi_line(const std::vector<std::vector<Type>>& ori, std::string gap) {
	std::vector<std::string> res; res.reserve(ori.size());
	for (size_t i = 0; i < ori.size(); i++) res.push_back(combine_to_string<Type>(ori.at(i), gap));
	return res;
}

template<typename Type>
void force_boundary(std::vector<Type>& data, const std::vector<Type>& lower, const std::vector<Type>& upper) {
	if (isNumber(typeid(Type))) {
		if (data.size() != lower.size() || lower.size()!= upper.size()) throw exception::size_not_match(data.size(), lower.size(), upper.size());
		for (size_t i = 0; i < data.size(); i++) {
			if (data.at(i) > upper.at(i)) data.at(i) = upper.at(i);
			if (data.at(i) < lower.at(i)) data.at(i) = lower.at(i);
		}
	}
	else throw exception::type_not_match(typeid(Type).name(), "not a number");
}

}