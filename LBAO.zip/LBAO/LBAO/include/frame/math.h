#pragma once

#include<vector>

namespace frame {

// one dim
class Interpolation
{
public:
	Interpolation(const std::vector<double>& x, const std::vector<double>& y);

	virtual double predict(double x) const = 0;
	virtual std::vector<double> predict(const std::vector<double>& x) const;

protected:
	std::vector<double> _x;
	std::vector<double> _y;
};

class LinearInterpolation : public Interpolation
{
public:
	LinearInterpolation(const std::vector<double>& x, const std::vector<double>& y);

	double predict(double x) const override;
	std::vector<double> predict(const std::vector<double>& x) const override;
};

class LagrangeInterpolation : public Interpolation
{
public:
	LagrangeInterpolation(const std::vector<double>& x, const std::vector<double>& y);

	double predict(double x) const override;
	std::vector<double> predict(const std::vector<double>& x) const override;
};

class InterpolationPoint
{
public:
	static double legendre(unsigned int n, double x);
	static double legendre_first_derivative(unsigned int n, double x);

	static std::vector<double> get_legendre_gauss_points(unsigned int n);
	//static std::vector<double> get_legendre_gauss_radau_points(unsigned int n);
	//static std::vector<double> get_legendre_gauss_lobatto_points(unsigned int n);
};

}