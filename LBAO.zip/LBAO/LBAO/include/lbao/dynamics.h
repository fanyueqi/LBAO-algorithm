#pragma once

#include<functional>
#include"data.h"
#include<optional>
#include"frame/ode_solver.h"

namespace lbao {
namespace dynamic {
	
class Dynamics
{
public:
	virtual void solve(Data&, std::optional<size_t> start, std::optional<size_t> end) const = 0;//[start,end)
	virtual mf::XVector<std::string, double> getTotalCost(const Data& dm, std::optional<size_t> tstart, std::optional<size_t> tend) const = 0; // �������壬[start,end)
	virtual mf::XVector<std::string, std::vector<double>> getSumCostByRange(const Data& dm, std::optional<size_t> tstart, std::optional<size_t> tend) const = 0; // �������壬[start,end)
	virtual mf::XVector<std::string, double> getCostAtTime(const Data& dm, size_t iTime) const = 0; //0��nTime-2��������nTime-1��final�������������壬�����ʱ�̲�������
	virtual mf::XVector<std::string, double> getCostAtFinal(const Data& dm) const = 0; //���ʱ�̲�������
};

class TimeMarchingSimulator : public Dynamics 
{
public:
	using RuntimeCostRule = std::function <double(const Data& dm, size_t tInd)>;
	using FinalCostRule = std::function <double(const Data& dm)>;
	using ImpulseCostRule = std::function <double(const Data& dm, size_t tInd)>;

	using ODE = mf::ODETimeMarchingSolver<Data, Data::Mat, Data::RowVec, Data::ColVec>;

	TimeMarchingSimulator(ODE::DiffRule diff, ODE::ImpRule imp, ODE::SolverType type);

	void addPlayerRule(std::string name, RuntimeCostRule run, FinalCostRule final, ImpulseCostRule imp);

	void solve(Data&, std::optional<size_t> start, std::optional<size_t> end) const override;
	mf::XVector<std::string, double> getTotalCost(const Data& dm, std::optional<size_t> tstart, std::optional<size_t> tend) const override; // �������壬[start,end)
	mf::XVector<std::string, std::vector<double>> getSumCostByRange(const Data& dm, std::optional<size_t> tstart, std::optional<size_t> tend) const override; // �������壬[start,end)
	mf::XVector<std::string, double> getCostAtTime(const Data& dm, size_t iTime) const override; //0��nTime-2��������nTime-1��final�������������壬�����ʱ�̲�������
	mf::XVector<std::string, double> getCostAtFinal(const Data& dm) const override; //���ʱ�̲�������

private:
	ODE::DiffRule _diffRule;
	ODE::ImpRule _impRule;
	ODE::SolverType _solverType;

	size_t nPlayer() const { return _runtimeCostRuleList.size(); }
	std::vector<RuntimeCostRule> _runtimeCostRuleList;
	std::vector<FinalCostRule> _finalCostRuleList;
	std::vector<ImpulseCostRule> _impulseCostRuleList;
	std::vector<std::string> _playerNameList;
};

}
}


