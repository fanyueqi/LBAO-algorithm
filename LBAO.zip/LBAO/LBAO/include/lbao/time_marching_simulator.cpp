
#include"dynamics.h"

namespace mf = frame;

lbao::dynamic::TimeMarchingSimulator::TimeMarchingSimulator(ODE::DiffRule diff, ODE::ImpRule imp, ODE::SolverType type)
	:_diffRule(diff), _impRule(imp), _solverType(type)
{
	// do nothing
}

void lbao::dynamic::TimeMarchingSimulator::solve(Data& dm, std::optional<size_t> start, std::optional<size_t> end) const{
	ODE ode(dm.state(), dm, _diffRule, _impRule, dm.getTimeSequence(), dm.getImpTimeSequence(), _solverType);
	ode.forward_range(start, end);
}

void lbao::dynamic::TimeMarchingSimulator::addPlayerRule(std::string name, RuntimeCostRule run, FinalCostRule final, ImpulseCostRule imp){
	_playerNameList.push_back(name); _runtimeCostRuleList.push_back(run);
	_finalCostRuleList.push_back(final); _impulseCostRuleList.push_back(imp);
}

mf::XVector<std::string, double> lbao::dynamic::TimeMarchingSimulator::getTotalCost(const Data& dm, std::optional<size_t> _tstart, std::optional<size_t> _tend) const {
	size_t tstart = 0, tend = dm.nTime();
	if (_tstart) tstart = *_tstart; if (_tend) tend = *_tend;
	if (tstart >= tend) throw mf::exception::bad_range(std::to_string(tstart), std::to_string(tend));
	if(tend > dm.nTime()) throw mf::exception::out_of_range(tend, 0, dm.nTime());

	auto temp = getSumCostByRange(dm, tstart, tend);
	mf::XVector<std::string, double> res;
	for (size_t i = 0; i < _playerNameList.size(); i++) {
		auto name = _playerNameList[i];
		res.add(name, temp.find(name).back());
	}
	return res;
}

mf::XVector<std::string, std::vector<double>> lbao::dynamic::TimeMarchingSimulator::getSumCostByRange(const Data& dm, std::optional<size_t> _tstart, std::optional<size_t> _tend) const {
	size_t tstart = 0, tend = dm.nTime();
	if (_tstart) tstart = *_tstart; if (_tend) tend = *_tend;
	if (tstart >= tend) throw mf::exception::bad_range(std::to_string(tstart), std::to_string(tend));
	if (tend > dm.nTime()) throw mf::exception::out_of_range(tend, 0, dm.nTime());

	mf::XVector<std::string, std::vector<double>> res;
	for (size_t i = 0; i < _playerNameList.size(); i++) res.add(_playerNameList[i], std::vector<double>(dm.nTime(), 0));

	mf::XVector<std::string, double> costAtTime = getCostAtTime(dm, tstart);
	for (size_t ind = 0; ind < _playerNameList.size(); ind++) {
		std::string name = _playerNameList[ind];
		res.find(name).at(tstart) = costAtTime.find(name);
	}
	for (size_t t = tstart + 1; t < tend; t++) {
		costAtTime = getCostAtTime(dm, t);
		for (size_t ind = 0; ind < _playerNameList.size(); ind++) {
			std::string name = _playerNameList[ind];
			std::vector<double>& cost = res.find(name);
			cost.at(t) = cost.at(t - 1) + costAtTime.find(name);
		}
	}
	// ����ǰ��
	if (tend == dm.nTime()) {
		costAtTime = getCostAtFinal(dm);
		for (size_t ind = 0; ind < _playerNameList.size(); ind++) {
			std::string name = _playerNameList[ind];
			std::vector<double>& cost = res.find(name);
			cost.at(tend - 1) = cost.at(tend - 2) + costAtTime.find(name); // �������մ���
		}
	}
	else {
		for (size_t t = tend; t < dm.nTime(); t++) {
			for (size_t ind = 0; ind < _playerNameList.size(); ind++) {
				std::string name = _playerNameList[ind];
				std::vector<double>& cost = res.find(name);
				cost.at(t) = cost.at(tend - 1);
			}
		}
	}
	return res;
}

mf::XVector<std::string, double> lbao::dynamic::TimeMarchingSimulator::getCostAtTime(const Data& dm, size_t t) const {
	if (t >= dm.nTime()) throw mf::exception::out_of_range(t, 0, dm.nTime() - 1);
	if (t == dm.nTime() - 1) return getCostAtFinal(dm);
	else {
		mf::XVector<std::string, double> res;
		for (size_t ind = 0; ind < _playerNameList.size(); ind++) {
			double val = 0;
			double h = dm.get_t(t + 1) - dm.get_t(t);
			if (_runtimeCostRuleList[ind]) val += _runtimeCostRuleList[ind](dm, t) * h;
			if (_impulseCostRuleList[ind] && dm.hasImpTime(dm.get_t(t), dm.get_t(t + 1))) val += _impulseCostRuleList[ind](dm, t);
			res.add(_playerNameList[ind], val);
		}
		return res;
	}
}

mf::XVector<std::string, double> lbao::dynamic::TimeMarchingSimulator::getCostAtFinal(const Data& dm) const {
	mf::XVector<std::string, double> res;
	for (size_t i = 0; i < _playerNameList.size(); i++) {
		if (_finalCostRuleList[i]) res.add(_playerNameList[i], _finalCostRuleList[i](dm));
		else res.add(_playerNameList[i], 0);
	}
	return res;
}



