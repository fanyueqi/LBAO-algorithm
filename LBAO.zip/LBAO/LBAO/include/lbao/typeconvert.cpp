
#include"typeconvert.h"
#include"../frame/except.h"

namespace mf = frame;

Eigen::RowVectorXd lbao::to_eigen_RowVec(const std::vector<double>& vec){
	return Eigen::RowVectorXd::Map(vec.data(), vec.size());
}

std::vector<double> lbao::to_std_vector(const Eigen::RowVectorXd& vec){
	return std::vector<double>(vec.data(), vec.data() + vec.size());
}

Eigen::MatrixXd lbao::to_eigen_Mat_by_row(const Eigen::RowVectorXd& vec, unsigned int sizeOfRow){
    if (vec.size() % sizeOfRow != 0) throw mf::exception::size_not_match(vec.size(), sizeOfRow);
    unsigned int rows = vec.size() / sizeOfRow;
    Eigen::MatrixXd result = Eigen::MatrixXd::Zero(rows, sizeOfRow);
    for (size_t i = 0; i < result.rows(); i++) result.row(i) = vec.segment(i*sizeOfRow, sizeOfRow);
    return result;
}

Eigen::MatrixXd lbao::to_eigen_Mat_by_row(const std::vector<double>& vec, unsigned int sizeOfRow){
    Eigen::RowVectorXd buff = to_eigen_RowVec(vec);
    return to_eigen_Mat_by_row(buff, sizeOfRow);
}

Eigen::MatrixXd lbao::to_eigen_Mat(const std::vector<std::vector<double>>& data){
    Eigen::MatrixXd res(data.size(), data.at(0).size());
    for (size_t i = 0; i < data.size(); i++) {
        if (data.at(i).size() != res.cols()) throw frame::exception::size_not_match(res.cols(), data.at(i).size());
        res.row(i) = lbao::to_eigen_RowVec(data.at(i));
    }
    return res;
}

std::vector<double> lbao::to_std_vector_by_row(const Eigen::MatrixXd& mat){
    std::vector<double> res; res.reserve(mat.rows() * mat.cols());
    for (size_t i = 0; i < mat.rows(); i++) {
        auto buff = to_std_vector(mat.row(i));
        res.insert(res.end(), buff.begin(), buff.end());
    }
    return res;
}
