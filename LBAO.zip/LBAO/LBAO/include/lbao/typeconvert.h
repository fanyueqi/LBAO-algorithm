#pragma once

#include<Eigen/Dense>
#include<vector>

namespace lbao {

Eigen::RowVectorXd to_eigen_RowVec(const std::vector<double>& data);
std::vector<double> to_std_vector(const Eigen::RowVectorXd& data);
Eigen::MatrixXd to_eigen_Mat_by_row(const Eigen::RowVectorXd& vec, unsigned int cols);
Eigen::MatrixXd to_eigen_Mat_by_row(const std::vector<double>& vec, unsigned int cols);
Eigen::MatrixXd to_eigen_Mat(const std::vector<std::vector<double>>& data);
std::vector<double> to_std_vector_by_row(const Eigen::MatrixXd& mat);

}