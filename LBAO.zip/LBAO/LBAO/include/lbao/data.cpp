
#include"data.h"
#include<numeric>

namespace mf = frame;
namespace md = lbao::dynamic;
using RowVec = std::vector<double>;
using Mat = std::vector<std::vector<double>>;

void md::Data::addConst(std::string name, const Argument& argu){
	_argu.add(name, argu); 
}

const md::Data::Argument& md::Data::getConst(std::string name) const { 
	return _argu.find(name); 
}

md::Data::Argument& md::Data::getConst(std::string name){
	return const_cast<Argument&>(std::as_const(*this).getConst(name));
}

void md::Data::addCtrlConst(std::string name, int nComponent, double val) {
	addCtrl(name, Mat(nTime(), RowVec(nComponent, val)));
}

void md::Data::addCtrlStatic(std::string name, const RowVec& init) {
	Mat m(nTime());
	for (size_t t = 0; t < nTime(); t++) m.at(t) = init;
	addCtrl(name, m);
}

void md::Data::addCtrl(std::string name, const Mat& mat) {
	// check rows
	if (nTime() == 0 || nTime() != mat.size()) throw mf::exception::size_not_match(nTime(), mat.size());

	// check cols
	size_t cols = mat.at(0).size();
	if (cols == 0) throw mf::exception::empty();
	for (size_t i = 0; i < mat.size(); i++) if (mat.at(i).size() != cols) throw mf::exception::size_not_match(cols, mat.at(i).size());

	_ctrl.add(name, mat, RowVec(), RowVec());
	addConst(Data::INIT + name, Argument(typeid(Mat)) = mat);
}

void md::Data::addImpCtrl(std::string name, const Mat& mat) {
	if (mat.size() != nImpTime() || mat.size() == 0) throw mf::exception::size_not_match(nImpTime(), mat.size());
	_imp_ctrl.add(name, mat);
	addConst(INIT + name, Argument(typeid(Mat)) = mat);
}

void md::Data::addImpCtrlConst(std::string name, int nComponent, double val) {
	addImpCtrl(name, Mat(nImpTime(), RowVec( nComponent, val) ));
}

void md::Data::addImpCtrlStatic(std::string name, const RowVec& init) {
	Mat m(nImpTime());
	for (size_t t = 0; t < m.size(); t++) m.at(t) = init;
	addImpCtrl(name, m);
}

void lbao::dynamic::Data::addState(std::string name, const Mat& mat, const RowVec& _minVal, const RowVec& _maxVal){
	// check rows
	if (nTime() == 0 || nTime() != mat.size()) throw mf::exception::size_not_match(nTime(), mat.size());

	// check cols
	size_t cols = mat.at(0).size();
	if (cols == 0) throw mf::exception::empty();
	for (size_t i = 0; i < mat.size(); i++) if (mat.at(i).size() != cols) throw mf::exception::size_not_match(cols, mat.at(i).size());

	RowVec minVal = _minVal; if (_minVal.size() == 0) minVal = RowVec(cols, pow(10, -9));
	RowVec maxVal = _maxVal; if (_maxVal.size() == 0) maxVal = RowVec(cols, pow(10, 9));

	if (minVal.size() != cols) throw mf::exception::size_not_match(cols, minVal.size());
	addConst(Data::MIN + name, Argument(typeid(RowVec)) = minVal);

	if (maxVal.size() != cols) throw mf::exception::size_not_match(cols, maxVal.size());
	addConst(Data::MAX + name, Argument(typeid(RowVec)) = maxVal);

	_state.add(name, mat, minVal, maxVal);
	_state.forceInBoundary(name);
	addConst(Data::INIT + name, Argument(typeid(Mat)) = _state.data().find(name));
}

void lbao::dynamic::Data::addStateInit(std::string name, const RowVec& init, const RowVec& minVal, const RowVec& maxVal){
	Mat m(nTime(), RowVec(init.size(), 0));
	m.at(0) = init;
	addState(name, m, minVal, maxVal);
}

void lbao::dynamic::Data::addStateConst(std::string name, int nComponent, double val, const RowVec& minVal, const RowVec& maxVal){
	Mat m(nTime(), RowVec(nComponent, 0));
	m.at(0) = RowVec(nComponent, val);
	addState(name, m, minVal, maxVal);
}

const md::Data::Function& lbao::dynamic::Data::state() const{
	return _state;
}

md::Data::Function& lbao::dynamic::Data::state(){
	return _state;
}
const md::Data::Function& lbao::dynamic::Data::ctrl() const{
	return _ctrl;
}
md::Data::Function& lbao::dynamic::Data::ctrl(){
	return _ctrl;
}

const RowVec& lbao::dynamic::Data::getImpCtrlAtImpulse(std::string name, size_t tInd) const{
	return _imp_ctrl.find(name).at(tInd);
}

const RowVec& lbao::dynamic::Data::getImpCtrlAtImpulse(size_t cInd, size_t tInd) const{
	return _imp_ctrl.at(cInd).at(tInd);
}

RowVec& lbao::dynamic::Data::getImpCtrlAtImpulse(std::string name, size_t tInd){
	return const_cast<RowVec&>(std::as_const(*this).getImpCtrlAtImpulse(name, tInd));
}

RowVec& lbao::dynamic::Data::getImpCtrlAtImpulse(size_t cInd, size_t tInd){
	return const_cast<RowVec&>(std::as_const(*this).getImpCtrlAtImpulse(cInd, tInd));
}

std::string lbao::dynamic::Data::getImpCtrlName(size_t cInd) const{
	return _imp_ctrl.key(cInd);
}

const RowVec& lbao::dynamic::Data::getImpTimeSequence() const{
	return _imp_time; 
}

const RowVec& lbao::dynamic::Data::getTimeSequence() const {
	return _time; 
}

double lbao::dynamic::Data::get_t(size_t ind) const {
	return _time.at(ind); 
}

double lbao::dynamic::Data::get_imp_t(size_t ind) const { 
	return _imp_time.at(ind);
}

bool lbao::dynamic::Data::hasImpTime(double start, double end) const{
	return mf::hasElement(_imp_time, start, end);
}

size_t lbao::dynamic::Data::findImpTimePointIndexByTimeIndex(size_t timeIndex) const {
	double t1 = _time.at(timeIndex); double t2 = _time.at(timeIndex + 1);
	for (size_t i = 0; i < _imp_time.size(); i++) if (t1 <= _imp_time.at(i) && _imp_time.at(i) <= t2) return i;
	throw mf::exception::find_no_element("", std::to_string(timeIndex), "imp_time");
}

size_t lbao::dynamic::Data::findLeftTimeIndex_by_t(double t) const { 
	for (size_t i = 0; i < _time.size() - 1; i++)  if (_time.at(i) <= t && t < _time.at(i + 1)) return i;
	if (t == _time.back()) return _time.size() - 1;
	throw mf::exception::find_no_element("", std::to_string(t), "time");
}

size_t lbao::dynamic::Data::nState() const{
	return _state.size(); 
}

size_t lbao::dynamic::Data::nCtrl() const { 
	return _ctrl.size();
}

size_t lbao::dynamic::Data::nImpCtrl() const { 
	return _imp_ctrl.size();
}

size_t lbao::dynamic::Data::nTime() const { 
	return _time.size(); 
}

size_t lbao::dynamic::Data::nImpTime() const { 
	return _imp_time.size(); 
}

size_t lbao::dynamic::Data::nStateDim(size_t ind) const {
	return _state.nDim().at(ind);
}

size_t lbao::dynamic::Data::nCtrlDim(size_t ind) const {
	return _ctrl.nDim().at(ind);
}

std::vector<size_t> lbao::dynamic::Data::nStateDim_order() const{
	std::vector<size_t> res; res.reserve(nState());
	for (size_t i = 0; i < nState(); i++) res.push_back(nStateDim(i));
	return res;
}

md::Data::Data(double totalTime, double stepLength, const RowVec& impulTimePoint)
	: _state(
		[](RowVec& vec, size_t n, double val) { vec.assign(n, val); },
		[](ColVec& vec, size_t n, double val) { vec.assign(n, val); },
		[](const Mat& mat)->size_t { return mat.size(); },
		[](const Mat& mat)->size_t { 
			for (size_t i = 0; i < mat.size()-1; i++) 
				if (mat.at(i).size() != mat.at(i+1).size()) throw mf::exception::size_not_match(mat.at(i).size(), mat.at(i+1).size());
			return mat.back().size();
		},
		[](const RowVec& vec)->size_t { return vec.size(); },
			[](const Mat& mat, size_t t)->const RowVec& {return mat.at(t); },
			[](const RowVec& vec, size_t t)->const double& {return vec.at(t); },
			[](ColVec& vec, size_t t)->double& {return vec.at(t); },
			[](RowVec& a, const RowVec& b) { using namespace frame; a += b; },
			[](RowVec& a, const RowVec& b) { using namespace frame; a -= b; },
			[](RowVec& vec, const RowVec& minVal, const RowVec& maxVal) { mf::force_boundary(vec, minVal, maxVal); }
		),
	_ctrl(
		[](RowVec& vec, size_t n, double val) { vec.assign(n, val); },
		[](ColVec& vec, size_t n, double val) { vec.assign(n, val); },
		[](const Mat& mat)->size_t { return mat.size(); },
		[](const Mat& mat)->size_t {
			for (size_t i = 0; i < mat.size() - 1; i++)
				if (mat.at(i).size() != mat.at(i + 1).size()) throw mf::exception::size_not_match(mat.at(i).size(), mat.at(i + 1).size());
			return mat.back().size();
		},
		[](const RowVec& vec)->size_t { return vec.size(); },
			[](const Mat& mat, size_t t)->const RowVec& {return mat.at(t); },
			[](const RowVec& vec, size_t t)->const double& {return vec.at(t); },
			[](ColVec& vec, size_t t)->double& {return vec.at(t); },
			[](RowVec& a, const RowVec& b) { using namespace frame; a += b; },
			[](RowVec& a, const RowVec& b) { using namespace frame; a -= b; },
			[](RowVec& vec, const RowVec& minVal, const RowVec& maxVal) { mf::force_boundary(vec, minVal, maxVal); }
			)
{
	if (stepLength <= 0 || totalTime <= 0) throw mf::exception::empty();
	int nTime = mf::getPreciseCeil(totalTime / stepLength) + 1;
	for (size_t t = 0; t < nTime; t++) _time.push_back(t * stepLength);
	addConst(Data::TIME, Argument(typeid(RowVec)) = _time);
	addConst(StrTotalTime, Argument(typeid(double)) = totalTime); 
	addConst(StrStepLength, Argument(typeid(double)) = stepLength);

	if (impulTimePoint.size() > 0) {
		_imp_time = impulTimePoint;
		auto index = mf::sort(_imp_time, true);
		mf::rearrange(index, _imp_time);
		addConst(Data::IMP_TIME, Argument(typeid(RowVec)) = _imp_time);
		// check if repeated elements
		for (size_t i = 0; i < _imp_time.size() - 1; i++)
			if (findLeftTimeIndex_by_t(_imp_time[i]) == findLeftTimeIndex_by_t(_imp_time[i + 1]))
				throw mf::exception::repeated_element(std::to_string(_imp_time[i]), "imp_time");
	}
}

double md::Data::getTotalTime() const {
	return getConst(StrTotalTime).dVal();
}

double md::Data::getStepLength() const {
	return getConst(StrStepLength).dVal();
}

const RowVec& md::Data::getStateUpperBound(size_t ind) const {
	return getConst(Data::MAX + _state.getName(ind)).dVec();
}

const RowVec& md::Data::getStateLowerBound(size_t ind) const {
	return getConst(Data::MIN + _state.getName(ind)).dVec();
}

mf::XVector<std::string, std::vector<double>> lbao::dynamic::Data::getAvgState() const {
	mf::XVector<std::string, std::vector<double>> res;
	for (size_t i = 0; i < _state.size(); i++) {
		ColVec avgState; avgState.reserve(nTime());
		for (size_t t = 0; t < nTime(); t++) 
			avgState.push_back(std::accumulate(_state.getValueAtTime(i, t).begin(), _state.getValueAtTime(i, t).end(), 0)/ nStateDim(i));
		res.add(_state.getName(i), avgState);
	}
	return res;
}

mf::XVector<std::string, md::Data::Argument_ReadOnly> md::Data::getConst_ReadOnly() const {
	mf::XVector<std::string, md::Data::Argument_ReadOnly> res;
	for (size_t i = 0; i < _argu.size(); i++) res.add(_argu.key(i), md::Data::Argument_ReadOnly(_argu.at(i)));
	return res;
}