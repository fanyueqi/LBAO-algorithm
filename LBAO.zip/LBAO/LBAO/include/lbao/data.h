#pragma once

#include"frame/xvector.h"
#include"frame/except.h"
#include<typeinfo>
#include<frame/toolkit.h>
#include"frame/variable.h"
#include <optional>
#include"frame/constant.h"
#include"frame/function.h"

namespace lbao {
	namespace mf = frame;
}

namespace lbao{
namespace dynamic {

class Data
{
public:
	using RowVec = std::vector<double>;
	using ColVec = std::vector<double>;
	using Mat = std::vector<std::vector<double>>;
	using Argument = mf::Constant<std::vector<int>, RowVec, std::vector<std::vector<int>>, Mat, mf::HighDimVariable<int>, mf::HighDimVariable<double>>;
	using Argument_ReadOnly = mf::Constant_ReadOnly<std::vector<int>, RowVec, std::vector<std::vector<int>>, Mat, mf::HighDimVariable<int>, mf::HighDimVariable<double>>;
	using Function = mf::Function<Mat, RowVec, ColVec>;

	Data(double totalTime, double stepLength, const RowVec& impulTimePoint); //������Զ�����

	double getTotalTime() const;
	double getStepLength() const;

	// state
	const Function& state() const;
	Function& state();
	void addState(std::string name, const Mat& mat, const RowVec& minVal, const RowVec& maxVal); //���߽粢ǿ�����ƣ����Ӳ���¼init�ͱ߽�
	void addStateInit(std::string name, const RowVec& init, const RowVec& minVal, const RowVec& maxVal);
	void addStateConst(std::string name, int nComponent, double val, const RowVec& minVal, const RowVec& maxVal);

	// ctrl
	const Function& ctrl() const;
	Function& ctrl();
	void addCtrlConst(std::string name, int nComponent, double val);
	void addCtrlStatic(std::string name, const RowVec& init);
	void addCtrl(std::string name, const Mat& mat); //����ctrl����¼initCtrl

	// constant
	void addConst(std::string name, const Argument& argu);
	const Argument& getConst(std::string name) const;
	Argument& getConst(std::string name);
	mf::XVector<std::string, Argument_ReadOnly> getConst_ReadOnly() const;

	// impulsive control
	void addImpCtrl(std::string name, const Mat& mat); //���Ӳ���¼init
	void addImpCtrlConst(std::string name, int nComponent, double val);
	void addImpCtrlStatic(std::string name, const RowVec& init);
	const RowVec& getImpCtrlAtImpulse(std::string name, size_t tInd) const;
	const RowVec& getImpCtrlAtImpulse(size_t cInd, size_t tInd) const;
	RowVec& getImpCtrlAtImpulse(std::string name, size_t tInd);
	RowVec& getImpCtrlAtImpulse(size_t cInd, size_t tInd);
	std::string getImpCtrlName(size_t cInd) const;

	// time
	const RowVec& getImpTimeSequence() const;
	const RowVec& getTimeSequence() const;
	double get_t(size_t ind) const;
	double get_imp_t(size_t ind) const;
	bool hasImpTime(double start, double end) const ; //[start,end) ��λᱻ����һ��
	size_t findImpTimePointIndexByTimeIndex(size_t timeIndex) const;
	size_t findLeftTimeIndex_by_t(double t) const;// t�����ĸ���������±�

	// count
	size_t nState() const;
	size_t nCtrl() const;
	size_t nImpCtrl() const;
	size_t nTime() const;
	size_t nImpTime() const;
	size_t nStateDim(size_t ind) const;
	size_t nCtrlDim(size_t ind) const;
	std::vector<size_t> nStateDim_order() const;
	
	// boundary
	const RowVec& getStateUpperBound(size_t ind) const;
	const RowVec& getStateLowerBound(size_t ind) const;

	// shortcut
	mf::XVector<std::string, RowVec> getAvgState() const;

protected:
	mf::XVector<std::string, Argument> _argu;
	RowVec _time;
	RowVec _imp_time;
	Function _state;
	Function _ctrl;
	mf::XVector<std::string, Mat> _imp_ctrl;

	static inline const std::string INIT = "init-";
	static inline const std::string MAX = "max-";
	static inline const std::string MIN = "min-";
	static inline const std::string TIME = "time";
	static inline const std::string IMP_TIME = "impulse time";
	static inline const std::string StrTotalTime = "total time";
	static inline const std::string StrStepLength = "step length";
};




}
}


