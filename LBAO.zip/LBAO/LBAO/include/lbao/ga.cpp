
#include"optimizer.h"

bool lbao::dynamic::StdVecGA::isEqual(const Chromosome& a, const Chromosome& b) const {
	return a==b;
}

void lbao::dynamic::StdVecGA::crossover(GA::CrossoverType type, Chromosome& a, Chromosome& b, double probability) const {
	if (type == GA::CrossoverType::UniformReplace) {
		for (size_t k = 0; k < a.size(); k++) {
			auto& aa = a.at(k); auto& bb = b.at(k);
			for (size_t i = 0; i < aa.size(); i++)
				if ( frame::randd(0, 1) <= probability) std::swap(aa.at(i), bb.at(i));
		}
	}
	else if (type == GA::CrossoverType::UniformArithmetic) {
		throw frame::exception::unknown();
	}
	else if (type == GA::CrossoverType::PiecewiseReplace) {
		throw frame::exception::unknown();
	}
	else throw frame::exception::unknown();
}

void lbao::dynamic::StdVecGA::mutation(Chromosome& chro, double probability, const Chromosome& source) const {
	for (size_t k = 0; k < chro.size(); k++) {
		auto& m = chro.at(k); const auto& m_source = source.at(k);
		for (size_t i = 0; i < m.size(); i++)
			if (frame::randd(0, 1) <= probability) m.at(i) = m_source.at(i);
	}
}

lbao::dynamic::StdVecGA::GA::Solution lbao::dynamic::StdVecGA::solve() {
	return Core.solve(this);
}

double lbao::dynamic::StdVecGA::calculateFitness(const Chromosome& chro) const {
	Data dm(_dm);
	decode(dm, chro);
	_sim->solve(dm, std::nullopt, std::nullopt);
	return _sim->getTotalCost(dm, std::nullopt, std::nullopt).at(_ind_of_opt_player);
}

void lbao::dynamic::StdVecGA::getOutput(const std::vector<Chromosome>& pop, const std::vector<double>& cost, Data& dm, Chromosome& chro) const {
	dm = _dm;
	int ind = max_element(cost.begin(), cost.end()) - cost.begin();
	chro = pop[ind];
	decode(dm, chro);
	_sim->solve(dm, std::nullopt, std::nullopt);
}