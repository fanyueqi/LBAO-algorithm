#pragma once

#pragma once

#include"data.h"
#include"dynamics.h"
#include"../frame/genetic_algorithm.h"

namespace lbao {
namespace dynamic{

class StdVecGA : public frame::GeneticAlgorithm<frame::XVector<std::string, std::vector<double>>>::Config
{
public:
	using Chromosome = frame::XVector<std::string, std::vector<double>>;
	using GA = frame::GeneticAlgorithm<Chromosome>;

	StdVecGA(const Data& dm, const Dynamics* const sim, size_t iPlayer) : _dm(dm), _sim(sim), _ind_of_opt_player(iPlayer) {}

	// ��Ҫʵ�ֵĽӿڣ�
	virtual void reportGeneration(const std::vector<Chromosome>&, const std::vector<double>&, int type) const = 0;
	virtual double fitnessMapping(double, const Chromosome&) const = 0;
	virtual Chromosome generate() const = 0;
	virtual void adjust(Chromosome&) const = 0;
	virtual void decode(Data& dm, const Chromosome& chro) const = 0;

	// ��ʵ�ֺ��˵Ľӿ�
	virtual double calculateFitness(const Chromosome& chro) const override;
	virtual void getOutput(const std::vector<Chromosome>&, const std::vector<double>&, Data&, Chromosome&) const;
	virtual bool isEqual(const Chromosome& a, const Chromosome& b) const override;
	virtual void crossover(frame::GeneticAlgorithm<Chromosome>::CrossoverType type, Chromosome& a, Chromosome& b, double probability) const override;
	virtual void mutation(Chromosome& chro, double probability, const Chromosome& source) const override;

	GA::Solution solve();

protected:
	const Data& _dm;
	const Dynamics* const _sim;
	size_t _ind_of_opt_player;
	GA Core;
};




}
}