﻿// lbao4mini.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
//

#include <iostream>
#include"frame/xvector.h"
#include"frame/threadpool.h"
#include"frame/variable.h"
#include"lbao/data.h"
#include"frame/toolkit.h"
#include<Eigen/Dense>
#include<string>
#include"lbao/dynamics.h"
#include"frame/meta_heuristic_base.h"
#include"frame/genetic_algorithm.h"
#include"lbao/optimizer.h"
#include"frame/math.h"
#include"frame/ode_solver.h"
#include"lbao/typeconvert.h"

frame::ThreadPool frame::ThreadPool::_inst(16);

using namespace std;
using namespace lbao;
using namespace lbao::dynamic;
using namespace frame;

using RowVec = Eigen::RowVectorXd;
using ColVec = Eigen::VectorXd;
using Mat = Eigen::MatrixXd;
using StdVec = std::vector<double>;
using StdMat = std::vector<StdVec>;

double alpha(const Data& dm, int i, double t);
double f(const Data& dm, double i, double j, const RowVec& l, double t);

Mat f(const Data& dm, const RowVec& l, double t) {
	int M = dm.getConst("M").iVal(); Mat res = Mat::Zero(M, M);
	for (int i = 0; i < M; i++) for (int j = 0; j < M; j++)  res(i, j) = f(dm, i, j, l, t);
	return res;
}

RowVec alpha(const Data& dm, double t) {
	int N = getPreciseInt(dm.getConst("N").iVal());
	RowVec res = RowVec::Zero(N); for (int i = 0; i < N; i++)  res(i) = alpha(dm, i, t);
	return res;
}

RowVec Gamma(const RowVec& x) {
	RowVec res = RowVec::Zero(x.size()); for (int i = 0; i < x.size(); i++) if (x(i) > 0) res(i) = 1; return res;
}

int Gamma(double x) {
	if (x > 0) return 1; else return 0;
}

XVector<string, StdVec> DiffState(const Data& dm, const XVector<std::string, StdVec>& base, double tt) {
	RowVec l = to_eigen_RowVec(base.find("l")); double l0 = base.find("l0").at(0);
	int tInd = dm.findLeftTimeIndex_by_t(tt);
	RowVec y = to_eigen_RowVec(dm.ctrl().getValueAtTime("y", tInd));
	int M = dm.getConst("M").iVal();
	Mat x = to_eigen_Mat_by_row(dm.ctrl().getValueAtTime("x", tInd), M);

	double beta0 = dm.getConst("beta0").dVal(); RowVec beta = to_eigen_RowVec(dm.getConst("beta").dVec());
	XVector<string, StdVec> res;

	double dl0dt = (Gamma(l) * (y).transpose())(0) - Gamma(l0) * beta0;
	Mat ff = f(dm, l, tt); RowVec one = RowVec::Ones(M);
	RowVec dldt = -Gamma(l).cwiseProduct(beta) - Gamma(l).cwiseProduct(y) + alpha(dm, tt) * x + one * ff - one * ff.transpose();
	res.add("l0", StdVec{ dl0dt });  res.add("l", to_std_vector(dldt));
	return res;
}

double CostAtTime(const Data& dm, int t) {
	double res = 0;
	double l0 = dm.state().getValueAtTime("l0", t).at(0); RowVec l = to_eigen_RowVec(dm.state().getValueAtTime("l", t));
	RowVec Dc = to_eigen_RowVec(dm.getConst("Dc").dVec()); double Dd = dm.getConst("Dd").dVal(); const Mat& De = to_eigen_Mat(dm.getConst("De").dMat());
	RowVec y = to_eigen_RowVec(dm.ctrl().getValueAtTime("y", t)); int M = dm.getConst("M").iVal();
	Mat x = to_eigen_Mat_by_row(dm.ctrl().getValueAtTime("x", t), M); int N = dm.getConst("N").iVal();
	ColVec one = ColVec::Ones(M);
	res += l0 + l.sum() + Dc.cwiseProduct(Gamma(l)).cwiseProduct(y).sum();
	res += Dd * (alpha(dm, dm.get_t(t)) * (x * one))(0, 0);
	Mat Df = De.cwiseProduct(f(dm, l, dm.get_t(t)));
	for (int i = 0; i < M; i++) res += Df.row(i).sum();
	return res;
}

double alpha(const Data& dm, int i, double t) {
	return i * dm.getConst("alpha0").dVal();
}

double f(const Data& dm, double i, double j, const RowVec& l, double t) {
	double fmax = dm.getConst("fmax").dVal(); if (l(i) > l(j)) return fmax; else return 0;
}

class MyGA : public StdVecGA
{
protected:
	double _T = 0; unsigned int _M = 0; unsigned int _N = 0; unsigned int _n = 0;
	double gettau(double t) const {
		return 2 * t / _T - 1;
	}
	double gett(double tau) const {
		return (tau + 1) * _T / 2;
	}
public:
	using Chromosome = Chromosome;
	MyGA(const Data& dm, const Dynamics* const sim, size_t iPlayer) : StdVecGA(dm, sim, iPlayer) {
		_T = dm.getTotalTime();
		_M = dm.getConst("M").iVal();
		_N = dm.getConst("N").iVal();
		_n = dm.getConst("n").iVal();
	}
	void reportGeneration(const std::vector<Chromosome>& popu, const std::vector<double>& fitness, int type) const override {
		return;
		if (type == GA::REPORT_FITNESS) {
			cout << "-----------------------------------" << endl;
			for (double c : fitness) cout << c << " "; cout << endl;
		}

	}
	double fitnessMapping(double x, const Chromosome& chro) const override { return -x; }
	Chromosome generate() const override {
		HighDimVariable<double> x(nullopt, vector<size_t>{_N, _M, _n}, 0); HighDimVariable<double> y(nullopt, vector<size_t>{_M, _n}, 0);
		x.setRand(0, 1); y.setRand(0, _dm.getConst("ymax").dVal());
		vector<double> c;
		c.insert(c.end(), x.getData().begin(), x.getData().end());
		c.insert(c.end(), y.getData().begin(), y.getData().end());
		Chromosome cc; cc.add("c", c); return cc;
	}
	void adjust(Chromosome& chro) const override {
		using Vec = vector<double>;
		using Index = vector<size_t>;
		auto& c = chro.at(0);

		HighDimVariable<double> x(nullopt, vector<size_t>{_N, _M, _n}, Vec(c.begin(), c.begin() + _N * _M * _n));
		HighDimVariable<double> y(nullopt, vector<size_t>{_M, _n}, Vec(c.begin() + _N * _M * _n, c.end()));
		for (size_t i = 0; i < _N; i++) {
			for (size_t k = 0; k < _n; k++) {
				double sum = 0; for (size_t j = 0; j < _M; j++) sum += x(Index{ i, j, k });
				for (size_t j = 0; j < _M; j++) x(Index{ i, j, k }) = x(Index{ i, j, k }) / sum;
			}
		}

		c.clear();
		c.insert(c.end(), x.getData().begin(), x.getData().end());
		c.insert(c.end(), y.getData().begin(), y.getData().end());
	}
	void decode(Data& dm, const Chromosome& chro) const override {
		using Vec = vector<double>;
		using Index = vector<size_t>;
		const auto& c = chro.at(0);
		HighDimVariable<double> x(nullopt, vector<size_t>{_N, _M, _n}, Vec(c.begin(), c.begin() + _N * _M * _n));
		HighDimVariable<double> y(nullopt, vector<size_t>{_M, _n}, Vec(c.begin() + _N * _M * _n, c.end()));

		vector<double> tauk = InterpolationPoint::get_legendre_gauss_points(_n);
		int nTime = dm.nTime();
		vector<Mat> resx; resx.reserve(nTime); for (int i = 0; i < nTime; i++) resx.push_back(Mat::Zero(_N, _M));
		vector<vector<double>> resy; resy.reserve(nTime); for (int i = 0; i < nTime; i++) resy.push_back(vector<double>(_M, 0));
		double ymax = dm.getConst("ymax").dVal();

		for (size_t i = 0; i < _N; i++) {
			for (size_t j = 0; j < _M; j++) {
				vector<double> xij; xij.reserve(_n); for (size_t k = 0; k < _n; k++) xij.push_back(x(Index{ i,j,k }));
				LagrangeInterpolation inter = LagrangeInterpolation(tauk, xij);
				for (size_t tInd = 0; tInd < nTime; tInd++) {
					double t = dm.get_t(tInd); double tau = gettau(t);
					double Xijtau = inter.predict(tau);
					if (Xijtau < 0) Xijtau = 0; if (Xijtau > 1) Xijtau = 1;
					resx.at(tInd)(i, j) = Xijtau;
				}
			}
		}

		for (size_t j = 0; j < _M; j++) {
			vector<double> yj; yj.reserve(_n); for (size_t k = 0; k < _n; k++) yj.push_back(y(Index{ j,k }));
			LagrangeInterpolation inter = LagrangeInterpolation(tauk, yj);
			for (size_t tInd = 0; tInd < nTime; tInd++) {
				double t = dm.get_t(tInd); double tau = gettau(t);
				double Yjtau = inter.predict(tau);
				if (Yjtau < 0) Yjtau = 0; if (Yjtau > ymax) Yjtau = ymax;
				resy.at(tInd).at(j) = Yjtau;
			}
		}

		for (size_t t = 0; t < nTime; t++) {
			Mat& xx = resx.at(t);
			for (int i = 0; i < _N; i++) {
				double sum = xx.row(i).sum();
				for (int j = 0; j < _M; j++) xx(i, j) = xx(i, j) / sum;
			}
			XVector<string, StdVec> ctrl;
			ctrl.add("y", resy.at(t));
			ctrl.add("x", to_std_vector_by_row(resx.at(t)));
			dm.ctrl().setValueAtTime(ctrl, t, "=");
		}
	}
};

int main()
{
	//return 0;

	double T = 6; int N = 3; int M = 2; int n = 5;
	double alpha0 = 6; double ymax = 2; double fmax = 0.2;
	double beta0 = 3; double betamin = 2; double betamax = 3;
	double Dcmin = 0.1; double Dcmax = 0.5; double Dd = 0.035; double Demin = 0.0001; double Demax = 0.005;


	///////////////////////////////////////////////////////////////////////////
	using Vec = std::vector<double>;
	Data dm(T, 0.01, Vec());
	using argu = Data::Argument;
	dm.addConst("Dc", argu( randd(Vec(M, Dcmin), Vec(M,Dcmax))));
	dm.addConst("Dd", argu(Dd));
	dm.addConst("N", argu(N));
	dm.addConst("M", argu(M));
	dm.addConst("n", argu(n));
	Data::Mat De; for(size_t i = 0; i < N; i++) De.push_back(randd(Vec(M, Demin), Vec(M, Demax)));
	dm.addConst("De", argu(De));  
	dm.addConst("alpha0", argu(alpha0));
	dm.addConst("beta0", argu(beta0));
	dm.addConst("ymax", argu(ymax));
	dm.addConst("fmax", argu(fmax));
	dm.addConst("beta", argu( randd(Vec(M, betamin), Vec(M, betamax) )));

	dm.addStateConst("l0", 1, 0, StdVec(1, 0), StdVec());
	dm.addStateConst("l", M, 0, StdVec(M, 0), StdVec());

	clock_t t1, t2;
	dm.addCtrlConst("x", N*M, 0);
	dm.addCtrlConst("y",M,0);

	TimeMarchingSimulator sim(DiffState, nullptr, TimeMarchingSimulator::ODE::SolverType::Euler);
	sim.addPlayerRule("latency", CostAtTime, nullptr, nullptr);

	MyGA ga(dm, &sim, 0);
	ga._max_iteration_step = 100;
	ga._n_thread = 12;
	ga._population_size = 120;

	t1 = clock();
	auto gasolu = ga.solve();
	t2 = clock();
	cout << totalRunTime(t1, t2) << endl;
	for (double val : gasolu.best_fitness_by_generation) cout << val << " ";
	cout << endl;

	try
	{

	}
	catch (const std::exception& e)
	{
		cout << e.what() << endl;
	}


	std::cout << "Hello World!\n";
}


